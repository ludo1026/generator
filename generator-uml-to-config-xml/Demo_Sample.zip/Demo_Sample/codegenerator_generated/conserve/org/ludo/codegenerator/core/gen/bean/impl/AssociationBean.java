/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : AssociationBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.AssociationAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IAssociation;

/**
 * <b>Description :</b>
 */
public class AssociationBean extends AssociationAbstractBean implements IAssociation, Serializable {

/* @zone-debut:{AssociationBean} */
/* @zone-fin:{AssociationBean} */

}
