/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : AttributBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.AttributAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IAttribut;

/**
 * <b>Description :</b>
 */
public class AttributBean extends AttributAbstractBean implements IAttribut, Serializable {

/* @zone-debut:{AttributBean} */
/* @zone-fin:{AttributBean} */

}
