/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : MethodeBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.MethodeAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IMethode;

/**
 * <b>Description :</b>
 */
public class MethodeBean extends MethodeAbstractBean implements IMethode, Serializable {

/* @zone-debut:{MethodeBean} */
/* @zone-fin:{MethodeBean} */

}
