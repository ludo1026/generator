/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : ParametreBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.ParametreAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IParametre;

/**
 * <b>Description :</b>
 */
public class ParametreBean extends ParametreAbstractBean implements IParametre, Serializable {

/* @zone-debut:{ParametreBean} */
/* @zone-fin:{ParametreBean} */

}
