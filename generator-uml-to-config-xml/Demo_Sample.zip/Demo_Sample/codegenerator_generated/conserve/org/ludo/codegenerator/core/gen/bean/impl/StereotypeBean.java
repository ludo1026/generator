/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : StereotypeBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.StereotypeAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IStereotype;

/**
 * <b>Description :</b>
 */
public class StereotypeBean extends StereotypeAbstractBean implements IStereotype, Serializable {

/* @zone-debut:{StereotypeBean} */
/* @zone-fin:{StereotypeBean} */

}
