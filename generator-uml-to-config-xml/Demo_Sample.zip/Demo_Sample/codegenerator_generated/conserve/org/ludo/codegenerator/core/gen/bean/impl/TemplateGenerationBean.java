/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : TemplateGenerationBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.TemplateGenerationAbstractBean;
import org.ludo.codegenerator.core.gen.bean.ITemplateGeneration;

/**
 * <b>Description :</b>
 */
public class TemplateGenerationBean extends TemplateGenerationAbstractBean implements ITemplateGeneration, Serializable {

/* @zone-debut:{TemplateGenerationBean} */
/* @zone-fin:{TemplateGenerationBean} */

}
