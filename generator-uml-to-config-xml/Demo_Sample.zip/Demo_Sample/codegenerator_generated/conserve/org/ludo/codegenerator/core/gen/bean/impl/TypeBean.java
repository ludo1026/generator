/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : TypeBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;

/* @zone-debut:{import} */
/* @zone-fin:{import} */

import org.ludo.codegenerator.core.gen.bean.abst.impl.TypeAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IType;

/**
 * <b>Description :</b>
 */
public class TypeBean extends TypeAbstractBean implements IType, Serializable {

/* @zone-debut:{TypeBean} */
/* @zone-fin:{TypeBean} */

}
