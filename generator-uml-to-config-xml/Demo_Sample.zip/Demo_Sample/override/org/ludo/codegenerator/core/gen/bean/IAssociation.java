/*
 * Package  : ${classeGeneration.getNomPackage()}
 * Source   : ${classeGeneration.getNomElementGenere()}.java
 */
package ${classeGeneration.getNomPackage()};

import java.io.Serializable;
import java.util.Date;


import ${beanAbstractInterfaceTemplateGeneration.getNomPackage()}.${beanAbstractInterfaceTemplateGeneration.getNomElementGenere()};

/**
 * <b>Description :</b>
 * ${classeGeneration.getNomElementGenere()}
 *
 */
public interface ${classeGeneration.getNomElementGenere()} extends ${beanAbstractInterfaceTemplateGeneration.getNomElementGenere()}, Serializable {

}
