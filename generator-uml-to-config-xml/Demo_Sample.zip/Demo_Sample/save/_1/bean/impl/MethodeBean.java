/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : MethodeBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.core.gen.bean.abst.impl.MethodeAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IMethode;

/**
 * <b>Description :</b>
 */
public class MethodeBean extends MethodeAbstractBean implements IMethode, Serializable {



}
