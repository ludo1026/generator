/*
 * Package  : org.ludo.codegenerator.core.gen.bean.impl
 * Source   : ParametreBean.java
 */
package org.ludo.codegenerator.core.gen.bean.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.core.gen.bean.abst.impl.ParametreAbstractBean;
import org.ludo.codegenerator.core.gen.bean.IParametre;

/**
 * <b>Description :</b>
 */
public class ParametreBean extends ParametreAbstractBean implements IParametre, Serializable {



}
