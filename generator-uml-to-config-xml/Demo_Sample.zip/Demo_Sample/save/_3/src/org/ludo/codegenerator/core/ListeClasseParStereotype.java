package org.ludo.codegenerator.core;

import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotype;
import org.ludo.utils.AssertHelper;

public class ListeClasseParStereotype {
	private final String stereotypeNom;
	private final IGenStereotype stereotype;
	private final List listeClasse;
	public ListeClasseParStereotype(IGenStereotype stereotype) {
		AssertHelper.assertNotNullArgument(stereotype, "stereotype");
		this.stereotype = stereotype;
		AssertHelper.assertDefined(stereotype.getNom(), "nom du stereotype");
		this.stereotypeNom = stereotype.getNom();
		this.listeClasse = new ArrayList();
	}
	public String getStereotypeNom() {
		return this.stereotype.getNom();
	}
	public IGenStereotype getStereotype() {
		return this.stereotype;
	}
	public void addClasse(IGenClasse classe) {
		AssertHelper.assertNotNullArgument(classe, "classe");
		this.listeClasse.add(classe);
	}
	public List getListeClasse() {
		return this.listeClasse;
	}
}
