/*
 * Package  : org.ludo.codegenerator.core.gen.bean.abst
 * Source   : ITypeAbstract.java
 */
package org.ludo.codegenerator.core.gen.bean.abst;

import java.io.Serializable;
import java.util.Date;


/**
 * <b>Description :</b>
 * @zone-debut:{#1}
 * @zone-fin:{#1}
 */
public interface ITypeAbstract extends Serializable {

    public java.lang.String getNomComplet();
    
    public void setNomComplet(java.lang.String nomComplet);
	

}
