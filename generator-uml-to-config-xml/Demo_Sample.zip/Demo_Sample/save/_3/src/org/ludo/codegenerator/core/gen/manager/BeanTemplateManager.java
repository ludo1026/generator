package org.ludo.codegenerator.core.gen.manager;

import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.core.gen.bean.IAssociation;
import org.ludo.codegenerator.core.gen.bean.IAttribut;
import org.ludo.codegenerator.core.gen.bean.IClasse;
import org.ludo.codegenerator.core.gen.bean.IMethode;
import org.ludo.codegenerator.core.gen.bean.IParametre;
import org.ludo.codegenerator.core.gen.bean.IStereotype;
import org.ludo.codegenerator.core.gen.bean.ITemplateGeneration;
import org.ludo.codegenerator.core.gen.bean.IType;
import org.ludo.codegenerator.core.gen.bean.impl.AssociationBean;
import org.ludo.codegenerator.core.gen.bean.impl.AttributBean;
import org.ludo.codegenerator.core.gen.bean.impl.ClasseBean;
import org.ludo.codegenerator.core.gen.bean.impl.MethodeBean;
import org.ludo.codegenerator.core.gen.bean.impl.ParametreBean;
import org.ludo.codegenerator.core.gen.bean.impl.StereotypeBean;
import org.ludo.codegenerator.core.gen.bean.impl.TypeBean;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociation;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociations;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttribut;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttributs;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethode;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethodes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenParametre;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenParametres;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRef;
import org.ludo.utils.AssertHelper;

public class BeanTemplateManager {
	
	private final IGen gen;
	private final List listeTemplateGeneration;
	
	public BeanTemplateManager(IGen gen, List listeTemplateGeneration) {
		AssertHelper.assertDefined(gen, "objet gen");
		this.gen = gen;
		AssertHelper.assertNotNull(listeTemplateGeneration, "objet liste des g�n�rations de template");
		if( ! listeTemplateGeneration.isEmpty() ) {
			AssertHelper.assertInstanceOf(listeTemplateGeneration.get(0), ITemplateGeneration.class, "objet liste des g�n�rations de template");
		}
		this.listeTemplateGeneration = listeTemplateGeneration;
		this.buildBeanTemplateManager();
	}
	
	private final void buildBeanTemplateManager() {
		this.defineListeTemplateGeneration(this.listeTemplateGeneration);
	}
	
	private BeanTemplateReferentielManager getReferentielManager() {
		return TemplateGenerationManager.getInstance().getBeanTemplateReferentielManager();
	}

	
	private void defineListeTemplateGeneration(List listeTemplateGeneration) {
		for(Iterator iterTemplateGeneration = listeTemplateGeneration.iterator(); iterTemplateGeneration.hasNext(); ) {
			ITemplateGeneration templateGeneration = (ITemplateGeneration) iterTemplateGeneration.next();
			switch(templateGeneration.getTypeTemplateGeneration()) {
			case ITemplateGeneration.TYPE_GENERATION__PAR_CLASSE :
				createClasseOfTemplateGeneration(templateGeneration);
				break;
			case ITemplateGeneration.TYPE_GENERATION__PAR_STEREOTYPE :
				createStereotypeOfTemplateGeneration(templateGeneration);
				break;
			case ITemplateGeneration.TYPE_GENERATION__PAR_TEMPLATE :
				createListeClasseOfTemplateGeneration(templateGeneration);
				break;
			}
		}
		for(Iterator iterClasse = getReferentielManager().getListeClasse().iterator(); iterClasse.hasNext(); ) {
			IClasse classe = (IClasse) iterClasse.next();
			defineClasse(classe);
		}
	}
	
	private ITemplateGeneration createListeClasseOfTemplateGeneration(ITemplateGeneration templateGeneration)
	{
		for(Iterator iterListeClasseParStereotype = templateGeneration.getMapListeClasseParStereotype().values().iterator(); iterListeClasseParStereotype.hasNext(); ) {
			List listeClasseParStereotype = (List) iterListeClasseParStereotype.next();
			for(Iterator iterClasse = listeClasseParStereotype.iterator(); iterClasse.hasNext(); ) {
				IGenClasse genClasse = (IGenClasse) iterClasse.next();
				IClasse classe = createClasse(genClasse);
				//classe
			}
		}
		IGenClasse genClasse = templateGeneration.getGenClasse();
		return templateGeneration;
	}
	
	private ITemplateGeneration createClasseOfTemplateGeneration(ITemplateGeneration templateGeneration)
	{
		IGenClasse genClasse = templateGeneration.getGenClasse();
		IClasse classe = (IClasse) createClasse(genClasse);
		templateGeneration.setClasse(classe);
		return templateGeneration;
	}
	
	private IClasse createClasse(IGenClasse genClasse)
	{
		IClasse classe = new ClasseBean();
		getReferentielManager().addClasse(classe);
		classe.setGenClasse(genClasse);
		classe.setGenId(classe.getGenId());
		classe.setNom(genClasse.getNomJava());
		classe.setNomPackage(genClasse.getPackageJava());
		
		return classe;
	}
	
	private ITemplateGeneration createStereotypeOfTemplateGeneration(ITemplateGeneration templateGeneration)
	{
		IGenStereotype genStereotype = templateGeneration.getGenStereotype();
		IStereotype stereotype = new StereotypeBean();
		getReferentielManager().addStereotype(stereotype);
		templateGeneration.addStereotype(stereotype);
		stereotype.setGenStereotype(genStereotype);
		stereotype.setNom(genStereotype.getNom());
		
		return templateGeneration;
	}
	
	private void defineClasse(IClasse classe)
	{
		IGenClasse genClasse = classe.getGenClasse();
		
		IGenAttributs genAttributs = genClasse.getGenAttributs();
		List listeGenAttribut = genAttributs.getListeGenAttribut();
		AssertHelper.assertNotNull(listeGenAttribut, "liste des attributs � g�n�rer");
		for( Iterator iterGenAttribut = listeGenAttribut.iterator(); iterGenAttribut.hasNext(); ) {
			IGenAttribut genAttribut = (IGenAttribut) iterGenAttribut.next();
			IAttribut attribut = new AttributBean();
			classe.addAttribut(attribut);
			attribut.setClasse(classe);
			attribut.setGenId(genAttribut.getGenId());
			attribut.setNom(genAttribut.getNomJava());
			IType type = new TypeBean();
			type.setNomComplet(genAttribut.getType());
			attribut.setType(type);
			//attribut.setEstClePrimaire(genAttribut.getEstClePrimaire());
			
		}
		
		IGenMethodes genMethodes = genClasse.getGenMethodes();
		List listeGenMethode = genMethodes.getListeGenMethode();
		AssertHelper.assertNotNull(listeGenMethode, "liste des methodes � g�n�rer");
		for( Iterator iterGenMethode = listeGenMethode.iterator(); iterGenMethode.hasNext(); ) {
			IGenMethode genMethode = (IGenMethode) iterGenMethode.next();
			IMethode methode = new MethodeBean();
			classe.addMethode(methode);
			methode.setClasse(classe);
			methode.setGenId(genMethode.getGenId());
			methode.setNom(genMethode.getNomJava());
			IType retourType = new TypeBean();
			retourType.setNomComplet(genMethode.getRetourType());
			methode.setRetourType(retourType);
			
			IGenParametres genParametres = genMethode.getGenParametres();
			List listeGenParametre = genParametres.getListeGenParametre();
			AssertHelper.assertNotNull(listeGenParametre, "liste des parametres � g�n�rer");
			for( Iterator iterGenParametre = listeGenParametre.iterator(); iterGenParametre.hasNext(); ) {
				IGenParametre genParametre = (IGenParametre) iterGenParametre.next();
				IParametre parametre = new ParametreBean();
				methode.addParametre(parametre);
				parametre.setMethode(methode);
				parametre.setGenId(genParametre.getGenId());
				parametre.setNom(genParametre.getNomJava());
				IType type = new TypeBean();
				type.setNomComplet(genParametre.getType());
				parametre.setType(type);
			}
		}
		
		IGenStereotypesRef genStereotypesRef = genClasse.getGenStereotypesRef();
		List listeGenStereotypeRef = genStereotypesRef.getListeGenStereotypeRef();
		AssertHelper.assertNotNull(listeGenStereotypeRef, "liste des stereotypeRef � g�n�rer");
		for( Iterator iterGenStereotypeRef = listeGenStereotypeRef.iterator(); iterGenStereotypeRef.hasNext(); ) {
			IGenStereotypeRef genStereotypeRef = (IGenStereotypeRef) iterGenStereotypeRef.next();
			IGenStereotypes genStereotypes = gen.getGenStereotypes();
			IGenStereotype genStereotype = genStereotypes.getGenStereotypeByNom(genStereotypeRef.getStereotypeNom());
			
			IStereotype stereotype = getReferentielManager().getStereotypeByNom(genStereotype.getNom());
			if( stereotype == null ) {
				stereotype = new StereotypeBean();
				getReferentielManager().addStereotype(stereotype);
			}
			classe.addStereotype(stereotype);
			stereotype.setNom(genStereotype.getNom());
			stereotype.addClasse(classe);
		}
		
		IGenAssociations genAssociations = genClasse.getGenAssociations();
		List listeGenAssociation = genAssociations.getListeGenAssociation();
		AssertHelper.assertNotNull(listeGenAssociation, "liste des associations � g�n�rer");
		for( Iterator iterGenAssociation = listeGenAssociation.iterator(); iterGenAssociation.hasNext(); ) {
			IGenAssociation genAssociation = (IGenAssociation) iterGenAssociation.next();
			IAssociation association = new AssociationBean();
			classe.addAssociation(association);
			association.setClasse(classe);
			String classeGenId = genAssociation.getClasseGenId();
			IClasse classeReference = getReferentielManager().getClasseByGenId(classeGenId);
			association.setClasseReference(classeReference);
			association.setGenId(genAssociation.getGenId());
			association.setClasseReferenceFromClasseGenIdOfGenAssociation(genAssociation.getClasseGenId());
			association.setNombreMinimumFromNombreMinimumOfGenAssociation(genAssociation.getNombreMinimum());
			association.setNombreMaximumFromNombreMaximumOfGenAssociation(genAssociation.getNombreMaximum());
			
		}
	}
	
}
