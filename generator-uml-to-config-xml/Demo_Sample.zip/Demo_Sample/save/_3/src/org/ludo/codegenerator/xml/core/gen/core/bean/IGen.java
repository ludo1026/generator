package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGen {
	
	/** R�cup�ration de l'�l�ment parent */
	
	/** R�cup�ration des �l�ments fils */

    public IGenTemplates getGenTemplates();
    
    public void setGenTemplates(IGenTemplates genTemplates);
	

    public IGenTemplateGroupes getGenTemplateGroupes();
    
    public void setGenTemplateGroupes(IGenTemplateGroupes genTemplateGroupes);
	

    public IGenStereotypes getGenStereotypes();
    
    public void setGenStereotypes(IGenStereotypes genStereotypes);
	

    public IGenClasses getGenClasses();
    
    public void setGenClasses(IGenClasses genClasses);
	

    public IGenGenererGroupe getGenGenererGroupe();
    
    public void setGenGenererGroupe(IGenGenererGroupe genGenererGroupe);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
