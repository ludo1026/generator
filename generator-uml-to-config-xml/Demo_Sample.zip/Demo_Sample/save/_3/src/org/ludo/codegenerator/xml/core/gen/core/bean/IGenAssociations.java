package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenAssociations {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenAssociation getGenAssociationByGenId(String genId);
    public IGenAssociation getGenAssociationByNomJavaChamp(String nomJavaChamp);
    public IGenAssociation getGenAssociationByClasseGenId(String classeGenId);
    public IGenAssociation getGenAssociationByNombreMinimum(String nombreMinimum);
    public IGenAssociation getGenAssociationByNombreMaximum(String nombreMaximum);
    public void addGenAssociation(IGenAssociation genAssociation);
    public List getListeGenAssociation();
    public void setListeGenAssociation(List listeGenAssociation);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
