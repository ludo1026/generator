package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenClasses getReferenceGenClasses();
	
	public void setReferenceGenClasses(IGenClasses referenceGenClasses);
	
	/** R�cup�ration des �l�ments fils */

    public IGenAttributs getGenAttributs();
    
    public void setGenAttributs(IGenAttributs genAttributs);
	

    public IGenMethodes getGenMethodes();
    
    public void setGenMethodes(IGenMethodes genMethodes);
	

    public IGenStereotypesRef getGenStereotypesRef();
    
    public void setGenStereotypesRef(IGenStereotypesRef genStereotypesRef);
	

    public IGenAssociations getGenAssociations();
    
    public void setGenAssociations(IGenAssociations genAssociations);
	

    public IGenClasseParents getGenClasseParents();
    
    public void setGenClasseParents(IGenClasseParents genClasseParents);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getGenIdAsString();
	public void setGenIdAsString(String genIdAsString);
	
	public String getNomJavaAsString();
	public void setNomJavaAsString(String nomJavaAsString);
	
	public String getPackageJavaAsString();
	public void setPackageJavaAsString(String packageJavaAsString);
	
	public String getNomTableAsString();
	public void setNomTableAsString(String nomTableAsString);
	
	public String getNomVueAsString();
	public void setNomVueAsString(String nomVueAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getGenId();
	public void setGenId(String genId);

	public String getNomJava();
	public void setNomJava(String nomJava);

	public String getPackageJava();
	public void setPackageJava(String packageJava);

	public String getNomTable();
	public void setNomTable(String nomTable);

	public String getNomVue();
	public void setNomVue(String nomVue);
}
