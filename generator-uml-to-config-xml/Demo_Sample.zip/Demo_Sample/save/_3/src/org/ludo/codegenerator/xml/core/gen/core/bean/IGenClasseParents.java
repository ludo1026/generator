package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClasseParents {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenClasseParent getGenClasseParentByClasseGenId(String classeGenId);
    public void addGenClasseParent(IGenClasseParent genClasseParent);
    public List getListeGenClasseParent();
    public void setListeGenClasseParent(List listeGenClasseParent);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
