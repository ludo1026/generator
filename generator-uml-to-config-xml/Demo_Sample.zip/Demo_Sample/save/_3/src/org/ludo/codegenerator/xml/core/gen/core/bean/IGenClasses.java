package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClasses {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenClasse getGenClasseByGenId(String genId);
    public IGenClasse getGenClasseByNomJava(String nomJava);
    public IGenClasse getGenClasseByPackageJava(String packageJava);
    public IGenClasse getGenClasseByNomTable(String nomTable);
    public IGenClasse getGenClasseByNomVue(String nomVue);
    public void addGenClasse(IGenClasse genClasse);
    public List getListeGenClasse();
    public void setListeGenClasse(List listeGenClasse);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getPackageBaseAsString();
	public void setPackageBaseAsString(String packageBaseAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getPackageBase();
	public void setPackageBase(String packageBase);
}
