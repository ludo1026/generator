package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClassesRefPourGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParClasse getReferenceGenGenererParClasse();
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenClasseRefPourGenererParClasse getGenClasseRefPourGenererParClasseByClasseGenId(String classeGenId);
    public void addGenClasseRefPourGenererParClasse(IGenClasseRefPourGenererParClasse genClasseRefPourGenererParClasse);
    public List getListeGenClasseRefPourGenererParClasse();
    public void setListeGenClasseRefPourGenererParClasse(List listeGenClasseRefPourGenererParClasse);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
