package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenGenererGroupe {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** R�cup�ration des �l�ments fils */

    public IGenGenererParClasses getGenGenererParClasses();
    
    public void setGenGenererParClasses(IGenGenererParClasses genGenererParClasses);
	

    public IGenGenererParTemplates getGenGenererParTemplates();
    
    public void setGenGenererParTemplates(IGenGenererParTemplates genGenererParTemplates);
	

    public IGenGenererParStereotypes getGenGenererParStereotypes();
    
    public void setGenGenererParStereotypes(IGenGenererParStereotypes genGenererParStereotypes);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
