package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParClasses getReferenceGenGenererParClasses();
	
	public void setReferenceGenGenererParClasses(IGenGenererParClasses referenceGenGenererParClasses);
	
	/** R�cup�ration des �l�ments fils */

    public IGenClassesRefPourGenererParClasse getGenClassesRefPourGenererParClasse();
    
    public void setGenClassesRefPourGenererParClasse(IGenClassesRefPourGenererParClasse genClassesRefPourGenererParClasse);
	

    public IGenTemplateGroupesRefPourGenererParClasse getGenTemplateGroupesRefPourGenererParClasse();
    
    public void setGenTemplateGroupesRefPourGenererParClasse(IGenTemplateGroupesRefPourGenererParClasse genTemplateGroupesRefPourGenererParClasse);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
