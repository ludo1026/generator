package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParClasses {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererGroupe getReferenceGenGenererGroupe();
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe);
	
	/** R�cup�ration des �l�ments fils */
	
    public void addGenGenererParClasse(IGenGenererParClasse genGenererParClasse);
    public List getListeGenGenererParClasse();
    public void setListeGenGenererParClasse(List listeGenGenererParClasse);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
