package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParStereotypes getReferenceGenGenererParStereotypes();
	
	public void setReferenceGenGenererParStereotypes(IGenGenererParStereotypes referenceGenGenererParStereotypes);
	
	/** R�cup�ration des �l�ments fils */

    public IGenStereotypesRefPourGenererParStereotype getGenStereotypesRefPourGenererParStereotype();
    
    public void setGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
