package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParStereotypes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererGroupe getReferenceGenGenererGroupe();
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe);
	
	/** R�cup�ration des �l�ments fils */
	
    public void addGenGenererParStereotype(IGenGenererParStereotype genGenererParStereotype);
    public List getListeGenGenererParStereotype();
    public void setListeGenGenererParStereotype(List listeGenGenererParStereotype);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
