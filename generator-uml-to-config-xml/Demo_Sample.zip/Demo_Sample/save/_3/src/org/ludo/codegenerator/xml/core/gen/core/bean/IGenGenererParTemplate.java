package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParTemplates getReferenceGenGenererParTemplates();
	
	public void setReferenceGenGenererParTemplates(IGenGenererParTemplates referenceGenGenererParTemplates);
	
	/** R�cup�ration des �l�ments fils */

    public IGenTemplateGroupesRefPourGenererParTemplate getGenTemplateGroupesRefPourGenererParTemplate();
    
    public void setGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
