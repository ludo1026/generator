package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParTemplates {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererGroupe getReferenceGenGenererGroupe();
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe);
	
	/** R�cup�ration des �l�ments fils */
	
    public void addGenGenererParTemplate(IGenGenererParTemplate genGenererParTemplate);
    public List getListeGenGenererParTemplate();
    public void setListeGenGenererParTemplate(List listeGenGenererParTemplate);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
