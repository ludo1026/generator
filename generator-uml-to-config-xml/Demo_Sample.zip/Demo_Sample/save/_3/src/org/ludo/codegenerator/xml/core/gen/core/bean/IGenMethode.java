package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenMethode {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenMethodes getReferenceGenMethodes();
	
	public void setReferenceGenMethodes(IGenMethodes referenceGenMethodes);
	
	/** R�cup�ration des �l�ments fils */

    public IGenParametres getGenParametres();
    
    public void setGenParametres(IGenParametres genParametres);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getGenIdAsString();
	public void setGenIdAsString(String genIdAsString);
	
	public String getNomJavaAsString();
	public void setNomJavaAsString(String nomJavaAsString);
	
	public String getRetourTypeAsString();
	public void setRetourTypeAsString(String retourTypeAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getGenId();
	public void setGenId(String genId);

	public String getNomJava();
	public void setNomJava(String nomJava);

	public String getRetourType();
	public void setRetourType(String retourType);
}
