package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenMethodes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenMethode getGenMethodeByGenId(String genId);
    public IGenMethode getGenMethodeByNomJava(String nomJava);
    public IGenMethode getGenMethodeByRetourType(String retourType);
    public void addGenMethode(IGenMethode genMethode);
    public List getListeGenMethode();
    public void setListeGenMethode(List listeGenMethode);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
