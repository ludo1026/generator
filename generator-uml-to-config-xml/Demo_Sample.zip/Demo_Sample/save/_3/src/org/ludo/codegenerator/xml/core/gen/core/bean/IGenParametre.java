package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenParametre {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenParametres getReferenceGenParametres();
	
	public void setReferenceGenParametres(IGenParametres referenceGenParametres);
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getGenIdAsString();
	public void setGenIdAsString(String genIdAsString);
	
	public String getNomJavaAsString();
	public void setNomJavaAsString(String nomJavaAsString);
	
	public String getTypeAsString();
	public void setTypeAsString(String typeAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getGenId();
	public void setGenId(String genId);

	public String getNomJava();
	public void setNomJava(String nomJava);

	public String getType();
	public void setType(String type);
}
