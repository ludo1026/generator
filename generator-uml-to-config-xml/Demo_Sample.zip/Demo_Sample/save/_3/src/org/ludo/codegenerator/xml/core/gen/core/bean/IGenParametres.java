package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenParametres {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenMethode getReferenceGenMethode();
	
	public void setReferenceGenMethode(IGenMethode referenceGenMethode);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenParametre getGenParametreByGenId(String genId);
    public IGenParametre getGenParametreByNomJava(String nomJava);
    public IGenParametre getGenParametreByType(String type);
    public void addGenParametre(IGenParametre genParametre);
    public List getListeGenParametre();
    public void setListeGenParametre(List listeGenParametre);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
