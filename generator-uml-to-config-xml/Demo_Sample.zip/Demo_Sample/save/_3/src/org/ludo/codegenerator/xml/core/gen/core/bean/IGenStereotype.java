package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenStereotypes getReferenceGenStereotypes();
	
	public void setReferenceGenStereotypes(IGenStereotypes referenceGenStereotypes);
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getNomAsString();
	public void setNomAsString(String nomAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getNom();
	public void setNom(String nom);
}
