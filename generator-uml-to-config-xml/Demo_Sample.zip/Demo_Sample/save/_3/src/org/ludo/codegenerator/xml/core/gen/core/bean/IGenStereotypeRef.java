package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenStereotypeRef {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenStereotypesRef getReferenceGenStereotypesRef();
	
	public void setReferenceGenStereotypesRef(IGenStereotypesRef referenceGenStereotypesRef);
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getStereotypeNomAsString();
	public void setStereotypeNomAsString(String stereotypeNomAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getStereotypeNom();
	public void setStereotypeNom(String stereotypeNom);
}
