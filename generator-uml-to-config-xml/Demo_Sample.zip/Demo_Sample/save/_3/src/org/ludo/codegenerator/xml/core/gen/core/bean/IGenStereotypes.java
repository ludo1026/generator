package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenStereotype getGenStereotypeByNom(String nom);
    public void addGenStereotype(IGenStereotype genStereotype);
    public List getListeGenStereotype();
    public void setListeGenStereotype(List listeGenStereotype);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
