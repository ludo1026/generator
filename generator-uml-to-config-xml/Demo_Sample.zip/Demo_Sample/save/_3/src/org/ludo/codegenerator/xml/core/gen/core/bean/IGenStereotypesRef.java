package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRef {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenStereotypeRef getGenStereotypeRefByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRef(IGenStereotypeRef genStereotypeRef);
    public List getListeGenStereotypeRef();
    public void setListeGenStereotypeRef(List listeGenStereotypeRef);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
