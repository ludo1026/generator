package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParStereotype getReferenceGenGenererParStereotype();
	
	public void setReferenceGenGenererParStereotype(IGenGenererParStereotype referenceGenGenererParStereotype);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenStereotypeRefPourGenererParStereotype getGenStereotypeRefPourGenererParStereotypeByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype genStereotypeRefPourGenererParStereotype);
    public List getListeGenStereotypeRefPourGenererParStereotype();
    public void setListeGenStereotypeRefPourGenererParStereotype(List listeGenStereotypeRefPourGenererParStereotype);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
