package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenTemplateGroupeRefPourGenererParTemplate getReferenceGenTemplateGroupeRefPourGenererParTemplate();
	
	public void setReferenceGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenStereotypeRefPourGenererParTemplate getGenStereotypeRefPourGenererParTemplateByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRefPourGenererParTemplate(IGenStereotypeRefPourGenererParTemplate genStereotypeRefPourGenererParTemplate);
    public List getListeGenStereotypeRefPourGenererParTemplate();
    public void setListeGenStereotypeRefPourGenererParTemplate(List listeGenStereotypeRefPourGenererParTemplate);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
