package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupe {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenTemplateGroupes getReferenceGenTemplateGroupes();
	
	public void setReferenceGenTemplateGroupes(IGenTemplateGroupes referenceGenTemplateGroupes);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenTemplateRef getGenTemplateRefByNom(String nom);
    public void addGenTemplateRef(IGenTemplateRef genTemplateRef);
    public List getListeGenTemplateRef();
    public void setListeGenTemplateRef(List listeGenTemplateRef);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getNomAsString();
	public void setNomAsString(String nomAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getNom();
	public void setNom(String nom);
}
