package org.ludo.codegenerator.xml.core.gen.core.bean;


public interface IGenTemplateGroupeRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenTemplateGroupesRefPourGenererParTemplate getReferenceGenTemplateGroupesRefPourGenererParTemplate();
	
	public void setReferenceGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate referenceGenTemplateGroupesRefPourGenererParTemplate);
	
	/** R�cup�ration des �l�ments fils */

    public IGenStereotypesRefPourGenererParTemplate getGenStereotypesRefPourGenererParTemplate();
    
    public void setGenStereotypesRefPourGenererParTemplate(IGenStereotypesRefPourGenererParTemplate genStereotypesRefPourGenererParTemplate);
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	public String getTemplateGroupeNomAsString();
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString);
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	

	public String getTemplateGroupeNom();
	public void setTemplateGroupeNom(String templateGroupeNom);
}
