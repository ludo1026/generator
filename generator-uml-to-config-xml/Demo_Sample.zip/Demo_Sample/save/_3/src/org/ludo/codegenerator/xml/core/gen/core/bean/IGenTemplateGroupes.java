package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenTemplateGroupe getGenTemplateGroupeByNom(String nom);
    public void addGenTemplateGroupe(IGenTemplateGroupe genTemplateGroupe);
    public List getListeGenTemplateGroupe();
    public void setListeGenTemplateGroupe(List listeGenTemplateGroupe);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
