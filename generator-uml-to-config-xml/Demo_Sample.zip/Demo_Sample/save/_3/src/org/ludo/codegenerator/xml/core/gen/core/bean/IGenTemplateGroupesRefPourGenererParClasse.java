package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParClasse getReferenceGenGenererParClasse();
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenTemplateGroupeRefPourGenererParClasse getGenTemplateGroupeRefPourGenererParClasseByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParClasse(IGenTemplateGroupeRefPourGenererParClasse genTemplateGroupeRefPourGenererParClasse);
    public List getListeGenTemplateGroupeRefPourGenererParClasse();
    public void setListeGenTemplateGroupeRefPourGenererParClasse(List listeGenTemplateGroupeRefPourGenererParClasse);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
