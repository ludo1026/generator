package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenStereotypeRefPourGenererParStereotype getReferenceGenStereotypeRefPourGenererParStereotype();
	
	public void setReferenceGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenTemplateGroupeRefPourGenererParStereotype getGenTemplateGroupeRefPourGenererParStereotypeByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParStereotype(IGenTemplateGroupeRefPourGenererParStereotype genTemplateGroupeRefPourGenererParStereotype);
    public List getListeGenTemplateGroupeRefPourGenererParStereotype();
    public void setListeGenTemplateGroupeRefPourGenererParStereotype(List listeGenTemplateGroupeRefPourGenererParStereotype);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
