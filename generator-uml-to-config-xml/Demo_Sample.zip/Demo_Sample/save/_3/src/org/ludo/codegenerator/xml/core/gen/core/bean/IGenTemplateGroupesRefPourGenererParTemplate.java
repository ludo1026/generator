package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	public IGenGenererParTemplate getReferenceGenGenererParTemplate();
	
	public void setReferenceGenGenererParTemplate(IGenGenererParTemplate referenceGenGenererParTemplate);
	
	/** R�cup�ration des �l�ments fils */
	
    public IGenTemplateGroupeRefPourGenererParTemplate getGenTemplateGroupeRefPourGenererParTemplateByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate genTemplateGroupeRefPourGenererParTemplate);
    public List getListeGenTemplateGroupeRefPourGenererParTemplate();
    public void setListeGenTemplateGroupeRefPourGenererParTemplate(List listeGenTemplateGroupeRefPourGenererParTemplate);
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
