package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttribut;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttributs;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;

public class AbstractGenAttributsBean implements IGenAttributs {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenClasse referenceGenClasse = null;
	
	public IGenClasse getReferenceGenClasse() {
		return referenceGenClasse;
	}
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse) {
		this.referenceGenClasse = referenceGenClasse;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenAttribut = new ArrayList();
	
    public IGenAttribut getGenAttributByGenId(String genId) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getGenId().equalsIgnoreCase(genId)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : genId de genAttribut = "+genId);
    }
    public IGenAttribut getGenAttributByNomJava(String nomJava) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getNomJava().equalsIgnoreCase(nomJava)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : nomJava de genAttribut = "+nomJava);
    }
    public IGenAttribut getGenAttributByType(String type) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getType().equalsIgnoreCase(type)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : type de genAttribut = "+type);
    }
    public IGenAttribut getGenAttributByNombreMinimum(String nombreMinimum) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getNombreMinimum().equalsIgnoreCase(nombreMinimum)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : nombreMinimum de genAttribut = "+nombreMinimum);
    }
    public IGenAttribut getGenAttributByNombreMaximum(String nombreMaximum) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getNombreMaximum().equalsIgnoreCase(nombreMaximum)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : nombreMaximum de genAttribut = "+nombreMaximum);
    }
    public IGenAttribut getGenAttributByNomSQL(String nomSQL) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getNomSQL().equalsIgnoreCase(nomSQL)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : nomSQL de genAttribut = "+nomSQL);
    }
    public IGenAttribut getGenAttributByTypeSQL(String typeSQL) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getTypeSQL().equalsIgnoreCase(typeSQL)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : typeSQL de genAttribut = "+typeSQL);
    }
    public IGenAttribut getGenAttributByEstDansTable(String estDansTable) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getEstDansTable().equalsIgnoreCase(estDansTable)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : estDansTable de genAttribut = "+estDansTable);
    }
    public IGenAttribut getGenAttributBySize(String size) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getSize().equalsIgnoreCase(size)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : size de genAttribut = "+size);
    }
    public IGenAttribut getGenAttributByEstClePrimaire(String estClePrimaire) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getEstClePrimaire().equalsIgnoreCase(estClePrimaire)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : estClePrimaire de genAttribut = "+estClePrimaire);
    }
    public IGenAttribut getGenAttributByEstCleIncrementee(String estCleIncrementee) {
        for(Iterator iter = listeGenAttribut.iterator(); iter.hasNext(); ) {
            GenAttributBean genAttribut = (GenAttributBean) iter.next();
            if(genAttribut.getEstCleIncrementee().equalsIgnoreCase(estCleIncrementee)) {
                return genAttribut;
            }
        }
        throw new IllegalStateException("La genAttribut n'est pas d�finie : estCleIncrementee de genAttribut = "+estCleIncrementee);
    }
    public void addGenAttribut(IGenAttribut genAttribut) {
    	genAttribut.setReferenceGenAttributs(this);
        listeGenAttribut.add(genAttribut);
    }
    public List getListeGenAttribut() {
        return listeGenAttribut;
    }
    public void setListeGenAttribut(List listeGenAttribut) {
        this.listeGenAttribut = listeGenAttribut;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
