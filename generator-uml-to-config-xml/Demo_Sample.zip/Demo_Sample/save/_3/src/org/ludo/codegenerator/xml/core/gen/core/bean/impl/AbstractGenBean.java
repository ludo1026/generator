package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplates;

public class AbstractGenBean implements IGen {
	
	/** R�cup�ration de l'�l�ment parent */
	
	/** R�cup�ration des �l�ments fils */

    private IGenTemplates genTemplates = null;
    
    public IGenTemplates getGenTemplates() {
    	return this.genTemplates;
    }
    
    public void setGenTemplates(IGenTemplates genTemplates) {
    	genTemplates.setReferenceGen(this);
    	this.genTemplates = genTemplates;
    }
	

    private IGenTemplateGroupes genTemplateGroupes = null;
    
    public IGenTemplateGroupes getGenTemplateGroupes() {
    	return this.genTemplateGroupes;
    }
    
    public void setGenTemplateGroupes(IGenTemplateGroupes genTemplateGroupes) {
    	genTemplateGroupes.setReferenceGen(this);
    	this.genTemplateGroupes = genTemplateGroupes;
    }
	

    private IGenStereotypes genStereotypes = null;
    
    public IGenStereotypes getGenStereotypes() {
    	return this.genStereotypes;
    }
    
    public void setGenStereotypes(IGenStereotypes genStereotypes) {
    	genStereotypes.setReferenceGen(this);
    	this.genStereotypes = genStereotypes;
    }
	

    private IGenClasses genClasses = null;
    
    public IGenClasses getGenClasses() {
    	return this.genClasses;
    }
    
    public void setGenClasses(IGenClasses genClasses) {
    	genClasses.setReferenceGen(this);
    	this.genClasses = genClasses;
    }
	

    private IGenGenererGroupe genGenererGroupe = null;
    
    public IGenGenererGroupe getGenGenererGroupe() {
    	return this.genGenererGroupe;
    }
    
    public void setGenGenererGroupe(IGenGenererGroupe genGenererGroupe) {
    	genGenererGroupe.setReferenceGen(this);
    	this.genGenererGroupe = genGenererGroupe;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
