package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociations;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttributs;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseParents;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethodes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRef;

public class AbstractGenClasseBean implements IGenClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenClasses referenceGenClasses = null;
	
	public IGenClasses getReferenceGenClasses() {
		return referenceGenClasses;
	}
	
	public void setReferenceGenClasses(IGenClasses referenceGenClasses) {
		this.referenceGenClasses = referenceGenClasses;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenAttributs genAttributs = null;
    
    public IGenAttributs getGenAttributs() {
    	return this.genAttributs;
    }
    
    public void setGenAttributs(IGenAttributs genAttributs) {
    	genAttributs.setReferenceGenClasse(this);
    	this.genAttributs = genAttributs;
    }
	

    private IGenMethodes genMethodes = null;
    
    public IGenMethodes getGenMethodes() {
    	return this.genMethodes;
    }
    
    public void setGenMethodes(IGenMethodes genMethodes) {
    	genMethodes.setReferenceGenClasse(this);
    	this.genMethodes = genMethodes;
    }
	

    private IGenStereotypesRef genStereotypesRef = null;
    
    public IGenStereotypesRef getGenStereotypesRef() {
    	return this.genStereotypesRef;
    }
    
    public void setGenStereotypesRef(IGenStereotypesRef genStereotypesRef) {
    	genStereotypesRef.setReferenceGenClasse(this);
    	this.genStereotypesRef = genStereotypesRef;
    }
	

    private IGenAssociations genAssociations = null;
    
    public IGenAssociations getGenAssociations() {
    	return this.genAssociations;
    }
    
    public void setGenAssociations(IGenAssociations genAssociations) {
    	genAssociations.setReferenceGenClasse(this);
    	this.genAssociations = genAssociations;
    }
	

    private IGenClasseParents genClasseParents = null;
    
    public IGenClasseParents getGenClasseParents() {
    	return this.genClasseParents;
    }
    
    public void setGenClasseParents(IGenClasseParents genClasseParents) {
    	genClasseParents.setReferenceGenClasse(this);
    	this.genClasseParents = genClasseParents;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getGenIdAsString() {
		return this.genId;
	}
	public void setGenIdAsString(String genIdAsString) {
		this.genId = genIdAsString;
	}

	public String getNomJavaAsString() {
		return this.nomJava;
	}
	public void setNomJavaAsString(String nomJavaAsString) {
		this.nomJava = nomJavaAsString;
	}

	public String getPackageJavaAsString() {
		return this.packageJava;
	}
	public void setPackageJavaAsString(String packageJavaAsString) {
		this.packageJava = packageJavaAsString;
	}

	public String getNomTableAsString() {
		return this.nomTable;
	}
	public void setNomTableAsString(String nomTableAsString) {
		this.nomTable = nomTableAsString;
	}

	public String getNomVueAsString() {
		return this.nomVue;
	}
	public void setNomVueAsString(String nomVueAsString) {
		this.nomVue = nomVueAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String genId = null;
	private String nomJava = null;
	private String packageJava = null;
	private String nomTable = null;
	private String nomVue = null;

	public String getGenId() {
		return this.genId;
	}
	public void setGenId(String genId) {
		this.genId = genId;
	}

	public String getNomJava() {
		return this.nomJava;
	}
	public void setNomJava(String nomJava) {
		this.nomJava = nomJava;
	}

	public String getPackageJava() {
		return this.packageJava;
	}
	public void setPackageJava(String packageJava) {
		this.packageJava = packageJava;
	}

	public String getNomTable() {
		return this.nomTable;
	}
	public void setNomTable(String nomTable) {
		this.nomTable = nomTable;
	}

	public String getNomVue() {
		return this.nomVue;
	}
	public void setNomVue(String nomVue) {
		this.nomVue = nomVue;
	}
}
