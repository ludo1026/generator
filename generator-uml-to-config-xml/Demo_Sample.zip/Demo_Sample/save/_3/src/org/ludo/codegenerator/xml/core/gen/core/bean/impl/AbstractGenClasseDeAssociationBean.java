package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociation;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseDeAssociation;

public class AbstractGenClasseDeAssociationBean implements IGenClasseDeAssociation {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenAssociation referenceGenAssociation = null;
	
	public IGenAssociation getReferenceGenAssociation() {
		return referenceGenAssociation;
	}
	
	public void setReferenceGenAssociation(IGenAssociation referenceGenAssociation) {
		this.referenceGenAssociation = referenceGenAssociation;
	}
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String get_typeAsString() {
		return this._type;
	}
	public void set_typeAsString(String _typeAsString) {
		this._type = _typeAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String _type = null;

	public String get_type() {
		return this._type;
	}
	public void set_type(String _type) {
		this._type = _type;
	}
}
