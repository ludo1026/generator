package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;

public class AbstractGenClasseRefPourGenererParClasseBean implements IGenClasseRefPourGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenClassesRefPourGenererParClasse referenceGenClassesRefPourGenererParClasse = null;
	
	public IGenClassesRefPourGenererParClasse getReferenceGenClassesRefPourGenererParClasse() {
		return referenceGenClassesRefPourGenererParClasse;
	}
	
	public void setReferenceGenClassesRefPourGenererParClasse(IGenClassesRefPourGenererParClasse referenceGenClassesRefPourGenererParClasse) {
		this.referenceGenClassesRefPourGenererParClasse = referenceGenClassesRefPourGenererParClasse;
	}
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getClasseGenIdAsString() {
		return this.classeGenId;
	}
	public void setClasseGenIdAsString(String classeGenIdAsString) {
		this.classeGenId = classeGenIdAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String classeGenId = null;

	public String getClasseGenId() {
		return this.classeGenId;
	}
	public void setClasseGenId(String classeGenId) {
		this.classeGenId = classeGenId;
	}
}
