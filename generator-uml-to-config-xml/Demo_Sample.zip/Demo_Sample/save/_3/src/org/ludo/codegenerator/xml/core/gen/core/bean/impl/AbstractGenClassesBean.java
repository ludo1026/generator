package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;

public class AbstractGenClassesBean implements IGenClasses {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGen referenceGen = null;
	
	public IGen getReferenceGen() {
		return referenceGen;
	}
	
	public void setReferenceGen(IGen referenceGen) {
		this.referenceGen = referenceGen;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenClasse = new ArrayList();
	
    public IGenClasse getGenClasseByGenId(String genId) {
        for(Iterator iter = listeGenClasse.iterator(); iter.hasNext(); ) {
            GenClasseBean genClasse = (GenClasseBean) iter.next();
            if(genClasse.getGenId().equalsIgnoreCase(genId)) {
                return genClasse;
            }
        }
        throw new IllegalStateException("La genClasse n'est pas d�finie : genId de genClasse = "+genId);
    }
    public IGenClasse getGenClasseByNomJava(String nomJava) {
        for(Iterator iter = listeGenClasse.iterator(); iter.hasNext(); ) {
            GenClasseBean genClasse = (GenClasseBean) iter.next();
            if(genClasse.getNomJava().equalsIgnoreCase(nomJava)) {
                return genClasse;
            }
        }
        throw new IllegalStateException("La genClasse n'est pas d�finie : nomJava de genClasse = "+nomJava);
    }
    public IGenClasse getGenClasseByPackageJava(String packageJava) {
        for(Iterator iter = listeGenClasse.iterator(); iter.hasNext(); ) {
            GenClasseBean genClasse = (GenClasseBean) iter.next();
            if(genClasse.getPackageJava().equalsIgnoreCase(packageJava)) {
                return genClasse;
            }
        }
        throw new IllegalStateException("La genClasse n'est pas d�finie : packageJava de genClasse = "+packageJava);
    }
    public IGenClasse getGenClasseByNomTable(String nomTable) {
        for(Iterator iter = listeGenClasse.iterator(); iter.hasNext(); ) {
            GenClasseBean genClasse = (GenClasseBean) iter.next();
            if(genClasse.getNomTable().equalsIgnoreCase(nomTable)) {
                return genClasse;
            }
        }
        throw new IllegalStateException("La genClasse n'est pas d�finie : nomTable de genClasse = "+nomTable);
    }
    public IGenClasse getGenClasseByNomVue(String nomVue) {
        for(Iterator iter = listeGenClasse.iterator(); iter.hasNext(); ) {
            GenClasseBean genClasse = (GenClasseBean) iter.next();
            if(genClasse.getNomVue().equalsIgnoreCase(nomVue)) {
                return genClasse;
            }
        }
        throw new IllegalStateException("La genClasse n'est pas d�finie : nomVue de genClasse = "+nomVue);
    }
    public void addGenClasse(IGenClasse genClasse) {
    	genClasse.setReferenceGenClasses(this);
        listeGenClasse.add(genClasse);
    }
    public List getListeGenClasse() {
        return listeGenClasse;
    }
    public void setListeGenClasse(List listeGenClasse) {
        this.listeGenClasse = listeGenClasse;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getPackageBaseAsString() {
		return this.packageBase;
	}
	public void setPackageBaseAsString(String packageBaseAsString) {
		this.packageBase = packageBaseAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String packageBase = null;

	public String getPackageBase() {
		return this.packageBase;
	}
	public void setPackageBase(String packageBase) {
		this.packageBase = packageBase;
	}
}
