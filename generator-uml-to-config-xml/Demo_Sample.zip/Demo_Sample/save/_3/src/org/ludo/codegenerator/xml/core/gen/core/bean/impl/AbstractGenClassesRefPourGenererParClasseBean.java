package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;

public class AbstractGenClassesRefPourGenererParClasseBean implements IGenClassesRefPourGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParClasse referenceGenGenererParClasse = null;
	
	public IGenGenererParClasse getReferenceGenGenererParClasse() {
		return referenceGenGenererParClasse;
	}
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse) {
		this.referenceGenGenererParClasse = referenceGenGenererParClasse;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenClasseRefPourGenererParClasse = new ArrayList();
	
    public IGenClasseRefPourGenererParClasse getGenClasseRefPourGenererParClasseByClasseGenId(String classeGenId) {
        for(Iterator iter = listeGenClasseRefPourGenererParClasse.iterator(); iter.hasNext(); ) {
            GenClasseRefPourGenererParClasseBean genClasseRefPourGenererParClasse = (GenClasseRefPourGenererParClasseBean) iter.next();
            if(genClasseRefPourGenererParClasse.getClasseGenId().equalsIgnoreCase(classeGenId)) {
                return genClasseRefPourGenererParClasse;
            }
        }
        throw new IllegalStateException("La genClasseRefPourGenererParClasse n'est pas d�finie : classeGenId de genClasseRefPourGenererParClasse = "+classeGenId);
    }
    public void addGenClasseRefPourGenererParClasse(IGenClasseRefPourGenererParClasse genClasseRefPourGenererParClasse) {
    	genClasseRefPourGenererParClasse.setReferenceGenClassesRefPourGenererParClasse(this);
        listeGenClasseRefPourGenererParClasse.add(genClasseRefPourGenererParClasse);
    }
    public List getListeGenClasseRefPourGenererParClasse() {
        return listeGenClasseRefPourGenererParClasse;
    }
    public void setListeGenClasseRefPourGenererParClasse(List listeGenClasseRefPourGenererParClasse) {
        this.listeGenClasseRefPourGenererParClasse = listeGenClasseRefPourGenererParClasse;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
