package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;

public class AbstractGenGenererGroupeBean implements IGenGenererGroupe {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGen referenceGen = null;
	
	public IGen getReferenceGen() {
		return referenceGen;
	}
	
	public void setReferenceGen(IGen referenceGen) {
		this.referenceGen = referenceGen;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenGenererParClasses genGenererParClasses = null;
    
    public IGenGenererParClasses getGenGenererParClasses() {
    	return this.genGenererParClasses;
    }
    
    public void setGenGenererParClasses(IGenGenererParClasses genGenererParClasses) {
    	genGenererParClasses.setReferenceGenGenererGroupe(this);
    	this.genGenererParClasses = genGenererParClasses;
    }
	

    private IGenGenererParTemplates genGenererParTemplates = null;
    
    public IGenGenererParTemplates getGenGenererParTemplates() {
    	return this.genGenererParTemplates;
    }
    
    public void setGenGenererParTemplates(IGenGenererParTemplates genGenererParTemplates) {
    	genGenererParTemplates.setReferenceGenGenererGroupe(this);
    	this.genGenererParTemplates = genGenererParTemplates;
    }
	

    private IGenGenererParStereotypes genGenererParStereotypes = null;
    
    public IGenGenererParStereotypes getGenGenererParStereotypes() {
    	return this.genGenererParStereotypes;
    }
    
    public void setGenGenererParStereotypes(IGenGenererParStereotypes genGenererParStereotypes) {
    	genGenererParStereotypes.setReferenceGenGenererGroupe(this);
    	this.genGenererParStereotypes = genGenererParStereotypes;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
