package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParClasse;

public class AbstractGenGenererParClasseBean implements IGenGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParClasses referenceGenGenererParClasses = null;
	
	public IGenGenererParClasses getReferenceGenGenererParClasses() {
		return referenceGenGenererParClasses;
	}
	
	public void setReferenceGenGenererParClasses(IGenGenererParClasses referenceGenGenererParClasses) {
		this.referenceGenGenererParClasses = referenceGenGenererParClasses;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenClassesRefPourGenererParClasse genClassesRefPourGenererParClasse = null;
    
    public IGenClassesRefPourGenererParClasse getGenClassesRefPourGenererParClasse() {
    	return this.genClassesRefPourGenererParClasse;
    }
    
    public void setGenClassesRefPourGenererParClasse(IGenClassesRefPourGenererParClasse genClassesRefPourGenererParClasse) {
    	genClassesRefPourGenererParClasse.setReferenceGenGenererParClasse(this);
    	this.genClassesRefPourGenererParClasse = genClassesRefPourGenererParClasse;
    }
	

    private IGenTemplateGroupesRefPourGenererParClasse genTemplateGroupesRefPourGenererParClasse = null;
    
    public IGenTemplateGroupesRefPourGenererParClasse getGenTemplateGroupesRefPourGenererParClasse() {
    	return this.genTemplateGroupesRefPourGenererParClasse;
    }
    
    public void setGenTemplateGroupesRefPourGenererParClasse(IGenTemplateGroupesRefPourGenererParClasse genTemplateGroupesRefPourGenererParClasse) {
    	genTemplateGroupesRefPourGenererParClasse.setReferenceGenGenererParClasse(this);
    	this.genTemplateGroupesRefPourGenererParClasse = genTemplateGroupesRefPourGenererParClasse;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
