package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;

public class AbstractGenGenererParClassesBean implements IGenGenererParClasses {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererGroupe referenceGenGenererGroupe = null;
	
	public IGenGenererGroupe getReferenceGenGenererGroupe() {
		return referenceGenGenererGroupe;
	}
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe) {
		this.referenceGenGenererGroupe = referenceGenGenererGroupe;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenGenererParClasse = new ArrayList();
	
    public void addGenGenererParClasse(IGenGenererParClasse genGenererParClasse) {
    	genGenererParClasse.setReferenceGenGenererParClasses(this);
        listeGenGenererParClasse.add(genGenererParClasse);
    }
    public List getListeGenGenererParClasse() {
        return listeGenGenererParClasse;
    }
    public void setListeGenGenererParClasse(List listeGenGenererParClasse) {
        this.listeGenGenererParClasse = listeGenGenererParClasse;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
