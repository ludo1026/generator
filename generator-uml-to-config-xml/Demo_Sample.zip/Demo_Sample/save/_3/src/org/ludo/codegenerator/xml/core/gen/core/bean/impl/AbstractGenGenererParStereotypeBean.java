package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;

public class AbstractGenGenererParStereotypeBean implements IGenGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParStereotypes referenceGenGenererParStereotypes = null;
	
	public IGenGenererParStereotypes getReferenceGenGenererParStereotypes() {
		return referenceGenGenererParStereotypes;
	}
	
	public void setReferenceGenGenererParStereotypes(IGenGenererParStereotypes referenceGenGenererParStereotypes) {
		this.referenceGenGenererParStereotypes = referenceGenGenererParStereotypes;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype = null;
    
    public IGenStereotypesRefPourGenererParStereotype getGenStereotypesRefPourGenererParStereotype() {
    	return this.genStereotypesRefPourGenererParStereotype;
    }
    
    public void setGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype) {
    	genStereotypesRefPourGenererParStereotype.setReferenceGenGenererParStereotype(this);
    	this.genStereotypesRefPourGenererParStereotype = genStereotypesRefPourGenererParStereotype;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
