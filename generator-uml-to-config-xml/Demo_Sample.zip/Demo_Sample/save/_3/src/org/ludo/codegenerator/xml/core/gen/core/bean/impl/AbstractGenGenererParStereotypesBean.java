package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;

public class AbstractGenGenererParStereotypesBean implements IGenGenererParStereotypes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererGroupe referenceGenGenererGroupe = null;
	
	public IGenGenererGroupe getReferenceGenGenererGroupe() {
		return referenceGenGenererGroupe;
	}
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe) {
		this.referenceGenGenererGroupe = referenceGenGenererGroupe;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenGenererParStereotype = new ArrayList();
	
    public void addGenGenererParStereotype(IGenGenererParStereotype genGenererParStereotype) {
    	genGenererParStereotype.setReferenceGenGenererParStereotypes(this);
        listeGenGenererParStereotype.add(genGenererParStereotype);
    }
    public List getListeGenGenererParStereotype() {
        return listeGenGenererParStereotype;
    }
    public void setListeGenGenererParStereotype(List listeGenGenererParStereotype) {
        this.listeGenGenererParStereotype = listeGenGenererParStereotype;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
