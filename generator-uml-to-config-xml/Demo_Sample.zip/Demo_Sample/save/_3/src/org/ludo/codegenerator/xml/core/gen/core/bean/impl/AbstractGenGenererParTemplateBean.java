package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;

public class AbstractGenGenererParTemplateBean implements IGenGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParTemplates referenceGenGenererParTemplates = null;
	
	public IGenGenererParTemplates getReferenceGenGenererParTemplates() {
		return referenceGenGenererParTemplates;
	}
	
	public void setReferenceGenGenererParTemplates(IGenGenererParTemplates referenceGenGenererParTemplates) {
		this.referenceGenGenererParTemplates = referenceGenGenererParTemplates;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate = null;
    
    public IGenTemplateGroupesRefPourGenererParTemplate getGenTemplateGroupesRefPourGenererParTemplate() {
    	return this.genTemplateGroupesRefPourGenererParTemplate;
    }
    
    public void setGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate) {
    	genTemplateGroupesRefPourGenererParTemplate.setReferenceGenGenererParTemplate(this);
    	this.genTemplateGroupesRefPourGenererParTemplate = genTemplateGroupesRefPourGenererParTemplate;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
