package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;

public class AbstractGenGenererParTemplatesBean implements IGenGenererParTemplates {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererGroupe referenceGenGenererGroupe = null;
	
	public IGenGenererGroupe getReferenceGenGenererGroupe() {
		return referenceGenGenererGroupe;
	}
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe) {
		this.referenceGenGenererGroupe = referenceGenGenererGroupe;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenGenererParTemplate = new ArrayList();
	
    public void addGenGenererParTemplate(IGenGenererParTemplate genGenererParTemplate) {
    	genGenererParTemplate.setReferenceGenGenererParTemplates(this);
        listeGenGenererParTemplate.add(genGenererParTemplate);
    }
    public List getListeGenGenererParTemplate() {
        return listeGenGenererParTemplate;
    }
    public void setListeGenGenererParTemplate(List listeGenGenererParTemplate) {
        this.listeGenGenererParTemplate = listeGenGenererParTemplate;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
