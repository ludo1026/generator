package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethode;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethodes;

public class AbstractGenMethodesBean implements IGenMethodes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenClasse referenceGenClasse = null;
	
	public IGenClasse getReferenceGenClasse() {
		return referenceGenClasse;
	}
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse) {
		this.referenceGenClasse = referenceGenClasse;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenMethode = new ArrayList();
	
    public IGenMethode getGenMethodeByGenId(String genId) {
        for(Iterator iter = listeGenMethode.iterator(); iter.hasNext(); ) {
            GenMethodeBean genMethode = (GenMethodeBean) iter.next();
            if(genMethode.getGenId().equalsIgnoreCase(genId)) {
                return genMethode;
            }
        }
        throw new IllegalStateException("La genMethode n'est pas d�finie : genId de genMethode = "+genId);
    }
    public IGenMethode getGenMethodeByNomJava(String nomJava) {
        for(Iterator iter = listeGenMethode.iterator(); iter.hasNext(); ) {
            GenMethodeBean genMethode = (GenMethodeBean) iter.next();
            if(genMethode.getNomJava().equalsIgnoreCase(nomJava)) {
                return genMethode;
            }
        }
        throw new IllegalStateException("La genMethode n'est pas d�finie : nomJava de genMethode = "+nomJava);
    }
    public IGenMethode getGenMethodeByRetourType(String retourType) {
        for(Iterator iter = listeGenMethode.iterator(); iter.hasNext(); ) {
            GenMethodeBean genMethode = (GenMethodeBean) iter.next();
            if(genMethode.getRetourType().equalsIgnoreCase(retourType)) {
                return genMethode;
            }
        }
        throw new IllegalStateException("La genMethode n'est pas d�finie : retourType de genMethode = "+retourType);
    }
    public void addGenMethode(IGenMethode genMethode) {
    	genMethode.setReferenceGenMethodes(this);
        listeGenMethode.add(genMethode);
    }
    public List getListeGenMethode() {
        return listeGenMethode;
    }
    public void setListeGenMethode(List listeGenMethode) {
        this.listeGenMethode = listeGenMethode;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
