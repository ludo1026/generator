package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethode;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenParametre;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenParametres;

public class AbstractGenParametresBean implements IGenParametres {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenMethode referenceGenMethode = null;
	
	public IGenMethode getReferenceGenMethode() {
		return referenceGenMethode;
	}
	
	public void setReferenceGenMethode(IGenMethode referenceGenMethode) {
		this.referenceGenMethode = referenceGenMethode;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenParametre = new ArrayList();
	
    public IGenParametre getGenParametreByGenId(String genId) {
        for(Iterator iter = listeGenParametre.iterator(); iter.hasNext(); ) {
            GenParametreBean genParametre = (GenParametreBean) iter.next();
            if(genParametre.getGenId().equalsIgnoreCase(genId)) {
                return genParametre;
            }
        }
        throw new IllegalStateException("La genParametre n'est pas d�finie : genId de genParametre = "+genId);
    }
    public IGenParametre getGenParametreByNomJava(String nomJava) {
        for(Iterator iter = listeGenParametre.iterator(); iter.hasNext(); ) {
            GenParametreBean genParametre = (GenParametreBean) iter.next();
            if(genParametre.getNomJava().equalsIgnoreCase(nomJava)) {
                return genParametre;
            }
        }
        throw new IllegalStateException("La genParametre n'est pas d�finie : nomJava de genParametre = "+nomJava);
    }
    public IGenParametre getGenParametreByType(String type) {
        for(Iterator iter = listeGenParametre.iterator(); iter.hasNext(); ) {
            GenParametreBean genParametre = (GenParametreBean) iter.next();
            if(genParametre.getType().equalsIgnoreCase(type)) {
                return genParametre;
            }
        }
        throw new IllegalStateException("La genParametre n'est pas d�finie : type de genParametre = "+type);
    }
    public void addGenParametre(IGenParametre genParametre) {
    	genParametre.setReferenceGenParametres(this);
        listeGenParametre.add(genParametre);
    }
    public List getListeGenParametre() {
        return listeGenParametre;
    }
    public void setListeGenParametre(List listeGenParametre) {
        this.listeGenParametre = listeGenParametre;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
