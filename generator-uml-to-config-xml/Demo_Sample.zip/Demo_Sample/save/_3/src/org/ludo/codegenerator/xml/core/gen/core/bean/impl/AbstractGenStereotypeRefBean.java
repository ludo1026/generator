package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRef;

public class AbstractGenStereotypeRefBean implements IGenStereotypeRef {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenStereotypesRef referenceGenStereotypesRef = null;
	
	public IGenStereotypesRef getReferenceGenStereotypesRef() {
		return referenceGenStereotypesRef;
	}
	
	public void setReferenceGenStereotypesRef(IGenStereotypesRef referenceGenStereotypesRef) {
		this.referenceGenStereotypesRef = referenceGenStereotypesRef;
	}
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getStereotypeNomAsString() {
		return this.stereotypeNom;
	}
	public void setStereotypeNomAsString(String stereotypeNomAsString) {
		this.stereotypeNom = stereotypeNomAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String stereotypeNom = null;

	public String getStereotypeNom() {
		return this.stereotypeNom;
	}
	public void setStereotypeNom(String stereotypeNom) {
		this.stereotypeNom = stereotypeNom;
	}
}
