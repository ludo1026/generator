package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;

public class AbstractGenStereotypeRefPourGenererParStereotypeBean implements IGenStereotypeRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenStereotypesRefPourGenererParStereotype referenceGenStereotypesRefPourGenererParStereotype = null;
	
	public IGenStereotypesRefPourGenererParStereotype getReferenceGenStereotypesRefPourGenererParStereotype() {
		return referenceGenStereotypesRefPourGenererParStereotype;
	}
	
	public void setReferenceGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype referenceGenStereotypesRefPourGenererParStereotype) {
		this.referenceGenStereotypesRefPourGenererParStereotype = referenceGenStereotypesRefPourGenererParStereotype;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenTemplateGroupesRefPourGenererParStereotype genTemplateGroupesRefPourGenererParStereotype = null;
    
    public IGenTemplateGroupesRefPourGenererParStereotype getGenTemplateGroupesRefPourGenererParStereotype() {
    	return this.genTemplateGroupesRefPourGenererParStereotype;
    }
    
    public void setGenTemplateGroupesRefPourGenererParStereotype(IGenTemplateGroupesRefPourGenererParStereotype genTemplateGroupesRefPourGenererParStereotype) {
    	genTemplateGroupesRefPourGenererParStereotype.setReferenceGenStereotypeRefPourGenererParStereotype(this);
    	this.genTemplateGroupesRefPourGenererParStereotype = genTemplateGroupesRefPourGenererParStereotype;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getStereotypeNomAsString() {
		return this.stereotypeNom;
	}
	public void setStereotypeNomAsString(String stereotypeNomAsString) {
		this.stereotypeNom = stereotypeNomAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String stereotypeNom = null;

	public String getStereotypeNom() {
		return this.stereotypeNom;
	}
	public void setStereotypeNom(String stereotypeNom) {
		this.stereotypeNom = stereotypeNom;
	}
}
