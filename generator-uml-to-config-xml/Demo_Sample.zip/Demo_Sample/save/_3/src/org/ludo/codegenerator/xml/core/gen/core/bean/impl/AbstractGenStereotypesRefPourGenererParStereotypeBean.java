package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;

public class AbstractGenStereotypesRefPourGenererParStereotypeBean implements IGenStereotypesRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParStereotype referenceGenGenererParStereotype = null;
	
	public IGenGenererParStereotype getReferenceGenGenererParStereotype() {
		return referenceGenGenererParStereotype;
	}
	
	public void setReferenceGenGenererParStereotype(IGenGenererParStereotype referenceGenGenererParStereotype) {
		this.referenceGenGenererParStereotype = referenceGenGenererParStereotype;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenStereotypeRefPourGenererParStereotype = new ArrayList();
	
    public IGenStereotypeRefPourGenererParStereotype getGenStereotypeRefPourGenererParStereotypeByStereotypeNom(String stereotypeNom) {
        for(Iterator iter = listeGenStereotypeRefPourGenererParStereotype.iterator(); iter.hasNext(); ) {
            GenStereotypeRefPourGenererParStereotypeBean genStereotypeRefPourGenererParStereotype = (GenStereotypeRefPourGenererParStereotypeBean) iter.next();
            if(genStereotypeRefPourGenererParStereotype.getStereotypeNom().equalsIgnoreCase(stereotypeNom)) {
                return genStereotypeRefPourGenererParStereotype;
            }
        }
        throw new IllegalStateException("La genStereotypeRefPourGenererParStereotype n'est pas d�finie : stereotypeNom de genStereotypeRefPourGenererParStereotype = "+stereotypeNom);
    }
    public void addGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype genStereotypeRefPourGenererParStereotype) {
    	genStereotypeRefPourGenererParStereotype.setReferenceGenStereotypesRefPourGenererParStereotype(this);
        listeGenStereotypeRefPourGenererParStereotype.add(genStereotypeRefPourGenererParStereotype);
    }
    public List getListeGenStereotypeRefPourGenererParStereotype() {
        return listeGenStereotypeRefPourGenererParStereotype;
    }
    public void setListeGenStereotypeRefPourGenererParStereotype(List listeGenStereotypeRefPourGenererParStereotype) {
        this.listeGenStereotypeRefPourGenererParStereotype = listeGenStereotypeRefPourGenererParStereotype;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
