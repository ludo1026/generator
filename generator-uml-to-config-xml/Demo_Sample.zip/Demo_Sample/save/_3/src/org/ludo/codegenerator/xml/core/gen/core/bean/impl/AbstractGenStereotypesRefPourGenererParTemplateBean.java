package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;

public class AbstractGenStereotypesRefPourGenererParTemplateBean implements IGenStereotypesRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate = null;
	
	public IGenTemplateGroupeRefPourGenererParTemplate getReferenceGenTemplateGroupeRefPourGenererParTemplate() {
		return referenceGenTemplateGroupeRefPourGenererParTemplate;
	}
	
	public void setReferenceGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate) {
		this.referenceGenTemplateGroupeRefPourGenererParTemplate = referenceGenTemplateGroupeRefPourGenererParTemplate;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenStereotypeRefPourGenererParTemplate = new ArrayList();
	
    public IGenStereotypeRefPourGenererParTemplate getGenStereotypeRefPourGenererParTemplateByStereotypeNom(String stereotypeNom) {
        for(Iterator iter = listeGenStereotypeRefPourGenererParTemplate.iterator(); iter.hasNext(); ) {
            GenStereotypeRefPourGenererParTemplateBean genStereotypeRefPourGenererParTemplate = (GenStereotypeRefPourGenererParTemplateBean) iter.next();
            if(genStereotypeRefPourGenererParTemplate.getStereotypeNom().equalsIgnoreCase(stereotypeNom)) {
                return genStereotypeRefPourGenererParTemplate;
            }
        }
        throw new IllegalStateException("La genStereotypeRefPourGenererParTemplate n'est pas d�finie : stereotypeNom de genStereotypeRefPourGenererParTemplate = "+stereotypeNom);
    }
    public void addGenStereotypeRefPourGenererParTemplate(IGenStereotypeRefPourGenererParTemplate genStereotypeRefPourGenererParTemplate) {
    	genStereotypeRefPourGenererParTemplate.setReferenceGenStereotypesRefPourGenererParTemplate(this);
        listeGenStereotypeRefPourGenererParTemplate.add(genStereotypeRefPourGenererParTemplate);
    }
    public List getListeGenStereotypeRefPourGenererParTemplate() {
        return listeGenStereotypeRefPourGenererParTemplate;
    }
    public void setListeGenStereotypeRefPourGenererParTemplate(List listeGenStereotypeRefPourGenererParTemplate) {
        this.listeGenStereotypeRefPourGenererParTemplate = listeGenStereotypeRefPourGenererParTemplate;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
