package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateRef;

public class AbstractGenTemplateGroupeBean implements IGenTemplateGroupe {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenTemplateGroupes referenceGenTemplateGroupes = null;
	
	public IGenTemplateGroupes getReferenceGenTemplateGroupes() {
		return referenceGenTemplateGroupes;
	}
	
	public void setReferenceGenTemplateGroupes(IGenTemplateGroupes referenceGenTemplateGroupes) {
		this.referenceGenTemplateGroupes = referenceGenTemplateGroupes;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplateRef = new ArrayList();
	
    public IGenTemplateRef getGenTemplateRefByNom(String nom) {
        for(Iterator iter = listeGenTemplateRef.iterator(); iter.hasNext(); ) {
            GenTemplateRefBean genTemplateRef = (GenTemplateRefBean) iter.next();
            if(genTemplateRef.getNom().equalsIgnoreCase(nom)) {
                return genTemplateRef;
            }
        }
        throw new IllegalStateException("La genTemplateRef n'est pas d�finie : nom de genTemplateRef = "+nom);
    }
    public void addGenTemplateRef(IGenTemplateRef genTemplateRef) {
    	genTemplateRef.setReferenceGenTemplateGroupe(this);
        listeGenTemplateRef.add(genTemplateRef);
    }
    public List getListeGenTemplateRef() {
        return listeGenTemplateRef;
    }
    public void setListeGenTemplateRef(List listeGenTemplateRef) {
        this.listeGenTemplateRef = listeGenTemplateRef;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getNomAsString() {
		return this.nom;
	}
	public void setNomAsString(String nomAsString) {
		this.nom = nomAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String nom = null;

	public String getNom() {
		return this.nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
}
