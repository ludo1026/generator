package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;

public class AbstractGenTemplateGroupeRefPourGenererParStereotypeBean implements IGenTemplateGroupeRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenTemplateGroupesRefPourGenererParStereotype referenceGenTemplateGroupesRefPourGenererParStereotype = null;
	
	public IGenTemplateGroupesRefPourGenererParStereotype getReferenceGenTemplateGroupesRefPourGenererParStereotype() {
		return referenceGenTemplateGroupesRefPourGenererParStereotype;
	}
	
	public void setReferenceGenTemplateGroupesRefPourGenererParStereotype(IGenTemplateGroupesRefPourGenererParStereotype referenceGenTemplateGroupesRefPourGenererParStereotype) {
		this.referenceGenTemplateGroupesRefPourGenererParStereotype = referenceGenTemplateGroupesRefPourGenererParStereotype;
	}
	
	/** R�cup�ration des �l�ments fils */
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getTemplateGroupeNomAsString() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString) {
		this.templateGroupeNom = templateGroupeNomAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String templateGroupeNom = null;

	public String getTemplateGroupeNom() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNom(String templateGroupeNom) {
		this.templateGroupeNom = templateGroupeNom;
	}
}
