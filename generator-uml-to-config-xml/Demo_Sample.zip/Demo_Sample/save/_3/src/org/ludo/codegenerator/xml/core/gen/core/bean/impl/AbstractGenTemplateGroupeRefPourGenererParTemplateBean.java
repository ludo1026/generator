package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;

public class AbstractGenTemplateGroupeRefPourGenererParTemplateBean implements IGenTemplateGroupeRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenTemplateGroupesRefPourGenererParTemplate referenceGenTemplateGroupesRefPourGenererParTemplate = null;
	
	public IGenTemplateGroupesRefPourGenererParTemplate getReferenceGenTemplateGroupesRefPourGenererParTemplate() {
		return referenceGenTemplateGroupesRefPourGenererParTemplate;
	}
	
	public void setReferenceGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate referenceGenTemplateGroupesRefPourGenererParTemplate) {
		this.referenceGenTemplateGroupesRefPourGenererParTemplate = referenceGenTemplateGroupesRefPourGenererParTemplate;
	}
	
	/** R�cup�ration des �l�ments fils */

    private IGenStereotypesRefPourGenererParTemplate genStereotypesRefPourGenererParTemplate = null;
    
    public IGenStereotypesRefPourGenererParTemplate getGenStereotypesRefPourGenererParTemplate() {
    	return this.genStereotypesRefPourGenererParTemplate;
    }
    
    public void setGenStereotypesRefPourGenererParTemplate(IGenStereotypesRefPourGenererParTemplate genStereotypesRefPourGenererParTemplate) {
    	genStereotypesRefPourGenererParTemplate.setReferenceGenTemplateGroupeRefPourGenererParTemplate(this);
    	this.genStereotypesRefPourGenererParTemplate = genStereotypesRefPourGenererParTemplate;
    }
	
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getTemplateGroupeNomAsString() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString) {
		this.templateGroupeNom = templateGroupeNomAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String templateGroupeNom = null;

	public String getTemplateGroupeNom() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNom(String templateGroupeNom) {
		this.templateGroupeNom = templateGroupeNom;
	}
}
