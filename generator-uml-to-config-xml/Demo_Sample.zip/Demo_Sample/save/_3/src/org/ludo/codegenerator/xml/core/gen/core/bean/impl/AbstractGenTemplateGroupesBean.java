package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupes;

public class AbstractGenTemplateGroupesBean implements IGenTemplateGroupes {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGen referenceGen = null;
	
	public IGen getReferenceGen() {
		return referenceGen;
	}
	
	public void setReferenceGen(IGen referenceGen) {
		this.referenceGen = referenceGen;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplateGroupe = new ArrayList();
	
    public IGenTemplateGroupe getGenTemplateGroupeByNom(String nom) {
        for(Iterator iter = listeGenTemplateGroupe.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeBean genTemplateGroupe = (GenTemplateGroupeBean) iter.next();
            if(genTemplateGroupe.getNom().equalsIgnoreCase(nom)) {
                return genTemplateGroupe;
            }
        }
        throw new IllegalStateException("La genTemplateGroupe n'est pas d�finie : nom de genTemplateGroupe = "+nom);
    }
    public void addGenTemplateGroupe(IGenTemplateGroupe genTemplateGroupe) {
    	genTemplateGroupe.setReferenceGenTemplateGroupes(this);
        listeGenTemplateGroupe.add(genTemplateGroupe);
    }
    public List getListeGenTemplateGroupe() {
        return listeGenTemplateGroupe;
    }
    public void setListeGenTemplateGroupe(List listeGenTemplateGroupe) {
        this.listeGenTemplateGroupe = listeGenTemplateGroupe;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
