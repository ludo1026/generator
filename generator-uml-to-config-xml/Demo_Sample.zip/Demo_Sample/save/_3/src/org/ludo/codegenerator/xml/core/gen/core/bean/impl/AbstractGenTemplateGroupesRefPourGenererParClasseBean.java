package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParClasse;

public class AbstractGenTemplateGroupesRefPourGenererParClasseBean implements IGenTemplateGroupesRefPourGenererParClasse {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParClasse referenceGenGenererParClasse = null;
	
	public IGenGenererParClasse getReferenceGenGenererParClasse() {
		return referenceGenGenererParClasse;
	}
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse) {
		this.referenceGenGenererParClasse = referenceGenGenererParClasse;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplateGroupeRefPourGenererParClasse = new ArrayList();
	
    public IGenTemplateGroupeRefPourGenererParClasse getGenTemplateGroupeRefPourGenererParClasseByTemplateGroupeNom(String templateGroupeNom) {
        for(Iterator iter = listeGenTemplateGroupeRefPourGenererParClasse.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeRefPourGenererParClasseBean genTemplateGroupeRefPourGenererParClasse = (GenTemplateGroupeRefPourGenererParClasseBean) iter.next();
            if(genTemplateGroupeRefPourGenererParClasse.getTemplateGroupeNom().equalsIgnoreCase(templateGroupeNom)) {
                return genTemplateGroupeRefPourGenererParClasse;
            }
        }
        throw new IllegalStateException("La genTemplateGroupeRefPourGenererParClasse n'est pas d�finie : templateGroupeNom de genTemplateGroupeRefPourGenererParClasse = "+templateGroupeNom);
    }
    public void addGenTemplateGroupeRefPourGenererParClasse(IGenTemplateGroupeRefPourGenererParClasse genTemplateGroupeRefPourGenererParClasse) {
    	genTemplateGroupeRefPourGenererParClasse.setReferenceGenTemplateGroupesRefPourGenererParClasse(this);
        listeGenTemplateGroupeRefPourGenererParClasse.add(genTemplateGroupeRefPourGenererParClasse);
    }
    public List getListeGenTemplateGroupeRefPourGenererParClasse() {
        return listeGenTemplateGroupeRefPourGenererParClasse;
    }
    public void setListeGenTemplateGroupeRefPourGenererParClasse(List listeGenTemplateGroupeRefPourGenererParClasse) {
        this.listeGenTemplateGroupeRefPourGenererParClasse = listeGenTemplateGroupeRefPourGenererParClasse;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
