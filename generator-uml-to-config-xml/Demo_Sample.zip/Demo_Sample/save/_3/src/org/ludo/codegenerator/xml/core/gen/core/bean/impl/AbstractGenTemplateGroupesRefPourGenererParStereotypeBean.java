package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;

public class AbstractGenTemplateGroupesRefPourGenererParStereotypeBean implements IGenTemplateGroupesRefPourGenererParStereotype {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype = null;
	
	public IGenStereotypeRefPourGenererParStereotype getReferenceGenStereotypeRefPourGenererParStereotype() {
		return referenceGenStereotypeRefPourGenererParStereotype;
	}
	
	public void setReferenceGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype) {
		this.referenceGenStereotypeRefPourGenererParStereotype = referenceGenStereotypeRefPourGenererParStereotype;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplateGroupeRefPourGenererParStereotype = new ArrayList();
	
    public IGenTemplateGroupeRefPourGenererParStereotype getGenTemplateGroupeRefPourGenererParStereotypeByTemplateGroupeNom(String templateGroupeNom) {
        for(Iterator iter = listeGenTemplateGroupeRefPourGenererParStereotype.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeRefPourGenererParStereotypeBean genTemplateGroupeRefPourGenererParStereotype = (GenTemplateGroupeRefPourGenererParStereotypeBean) iter.next();
            if(genTemplateGroupeRefPourGenererParStereotype.getTemplateGroupeNom().equalsIgnoreCase(templateGroupeNom)) {
                return genTemplateGroupeRefPourGenererParStereotype;
            }
        }
        throw new IllegalStateException("La genTemplateGroupeRefPourGenererParStereotype n'est pas d�finie : templateGroupeNom de genTemplateGroupeRefPourGenererParStereotype = "+templateGroupeNom);
    }
    public void addGenTemplateGroupeRefPourGenererParStereotype(IGenTemplateGroupeRefPourGenererParStereotype genTemplateGroupeRefPourGenererParStereotype) {
    	genTemplateGroupeRefPourGenererParStereotype.setReferenceGenTemplateGroupesRefPourGenererParStereotype(this);
        listeGenTemplateGroupeRefPourGenererParStereotype.add(genTemplateGroupeRefPourGenererParStereotype);
    }
    public List getListeGenTemplateGroupeRefPourGenererParStereotype() {
        return listeGenTemplateGroupeRefPourGenererParStereotype;
    }
    public void setListeGenTemplateGroupeRefPourGenererParStereotype(List listeGenTemplateGroupeRefPourGenererParStereotype) {
        this.listeGenTemplateGroupeRefPourGenererParStereotype = listeGenTemplateGroupeRefPourGenererParStereotype;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
