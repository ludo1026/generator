package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;

public class AbstractGenTemplateGroupesRefPourGenererParTemplateBean implements IGenTemplateGroupesRefPourGenererParTemplate {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGenGenererParTemplate referenceGenGenererParTemplate = null;
	
	public IGenGenererParTemplate getReferenceGenGenererParTemplate() {
		return referenceGenGenererParTemplate;
	}
	
	public void setReferenceGenGenererParTemplate(IGenGenererParTemplate referenceGenGenererParTemplate) {
		this.referenceGenGenererParTemplate = referenceGenGenererParTemplate;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplateGroupeRefPourGenererParTemplate = new ArrayList();
	
    public IGenTemplateGroupeRefPourGenererParTemplate getGenTemplateGroupeRefPourGenererParTemplateByTemplateGroupeNom(String templateGroupeNom) {
        for(Iterator iter = listeGenTemplateGroupeRefPourGenererParTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeRefPourGenererParTemplateBean genTemplateGroupeRefPourGenererParTemplate = (GenTemplateGroupeRefPourGenererParTemplateBean) iter.next();
            if(genTemplateGroupeRefPourGenererParTemplate.getTemplateGroupeNom().equalsIgnoreCase(templateGroupeNom)) {
                return genTemplateGroupeRefPourGenererParTemplate;
            }
        }
        throw new IllegalStateException("La genTemplateGroupeRefPourGenererParTemplate n'est pas d�finie : templateGroupeNom de genTemplateGroupeRefPourGenererParTemplate = "+templateGroupeNom);
    }
    public void addGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate genTemplateGroupeRefPourGenererParTemplate) {
    	genTemplateGroupeRefPourGenererParTemplate.setReferenceGenTemplateGroupesRefPourGenererParTemplate(this);
        listeGenTemplateGroupeRefPourGenererParTemplate.add(genTemplateGroupeRefPourGenererParTemplate);
    }
    public List getListeGenTemplateGroupeRefPourGenererParTemplate() {
        return listeGenTemplateGroupeRefPourGenererParTemplate;
    }
    public void setListeGenTemplateGroupeRefPourGenererParTemplate(List listeGenTemplateGroupeRefPourGenererParTemplate) {
        this.listeGenTemplateGroupeRefPourGenererParTemplate = listeGenTemplateGroupeRefPourGenererParTemplate;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
}
