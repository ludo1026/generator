package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplates;

public class AbstractGenTemplatesBean implements IGenTemplates {
	
	/** R�cup�ration de l'�l�ment parent */
	
	private IGen referenceGen = null;
	
	public IGen getReferenceGen() {
		return referenceGen;
	}
	
	public void setReferenceGen(IGen referenceGen) {
		this.referenceGen = referenceGen;
	}
	
	/** R�cup�ration des �l�ments fils */
	
    private List listeGenTemplate = new ArrayList();
	
    public IGenTemplate getGenTemplateByNom(String nom) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getNom().equalsIgnoreCase(nom)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : nom de genTemplate = "+nom);
    }
    public IGenTemplate getGenTemplateByFile(String file) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getFile().equalsIgnoreCase(file)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : file de genTemplate = "+file);
    }
    public IGenTemplate getGenTemplateByOutDir(String outDir) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getOutDir().equalsIgnoreCase(outDir)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : outDir de genTemplate = "+outDir);
    }
    public IGenTemplate getGenTemplateByOutFile(String outFile) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getOutFile().equalsIgnoreCase(outFile)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : outFile de genTemplate = "+outFile);
    }
    public IGenTemplate getGenTemplateByPackageJava(String packageJava) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getPackageJava().equalsIgnoreCase(packageJava)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : packageJava de genTemplate = "+packageJava);
    }
    public IGenTemplate getGenTemplateByNomElementGenere(String nomElementGenere) {
        for(Iterator iter = listeGenTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateBean genTemplate = (GenTemplateBean) iter.next();
            if(genTemplate.getNomElementGenere().equalsIgnoreCase(nomElementGenere)) {
                return genTemplate;
            }
        }
        throw new IllegalStateException("La genTemplate n'est pas d�finie : nomElementGenere de genTemplate = "+nomElementGenere);
    }
    public void addGenTemplate(IGenTemplate genTemplate) {
    	genTemplate.setReferenceGenTemplates(this);
        listeGenTemplate.add(genTemplate);
    }
    public List getListeGenTemplate() {
        return listeGenTemplate;
    }
    public void setListeGenTemplate(List listeGenTemplate) {
        this.listeGenTemplate = listeGenTemplate;
    }
	
	/** R�cup�ration des attributs de l'objet de base sans transtypage */
	

	public String getInDirAsString() {
		return this.inDir;
	}
	public void setInDirAsString(String inDirAsString) {
		this.inDir = inDirAsString;
	}

	public String getOutDirAsString() {
		return this.outDir;
	}
	public void setOutDirAsString(String outDirAsString) {
		this.outDir = outDirAsString;
	}

	public String getPackageJavaBaseAsString() {
		return this.packageJavaBase;
	}
	public void setPackageJavaBaseAsString(String packageJavaBaseAsString) {
		this.packageJavaBase = packageJavaBaseAsString;
	}
	
	/** R�cup�ration des attributs de l'objet de base avec transtypage */
	
	private String inDir = null;
	private String outDir = null;
	private String packageJavaBase = null;

	public String getInDir() {
		return this.inDir;
	}
	public void setInDir(String inDir) {
		this.inDir = inDir;
	}

	public String getOutDir() {
		return this.outDir;
	}
	public void setOutDir(String outDir) {
		this.outDir = outDir;
	}

	public String getPackageJavaBase() {
		return this.packageJavaBase;
	}
	public void setPackageJavaBase(String packageJavaBase) {
		this.packageJavaBase = packageJavaBase;
	}
}
