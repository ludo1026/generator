package org.ludo.codegenerator.xml.core.gen.core.bean.impl;


public class GenAttributBean extends AbstractGenAttributBean {
	
}
