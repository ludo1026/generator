package org.ludo.codegenerator.xml.core.gen.core.bean.impl;


public class GenMethodesBean extends AbstractGenMethodesBean {
	
}
