package org.ludo.codegenerator.xml.core.gen.core.bean.impl;


public class GenStereotypesRefPourGenererParStereotypeBean extends AbstractGenStereotypesRefPourGenererParStereotypeBean {
	
}
