package org.ludo.main;

public class BeanForTemplateGeneratorMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		org.ludo.umlgenerator.main.BeanForTemplateGeneratorMain.main(args);
		org.ludo.codegenerator.main.BeanForTemplateGeneratorMain.main(args);
	}

}
