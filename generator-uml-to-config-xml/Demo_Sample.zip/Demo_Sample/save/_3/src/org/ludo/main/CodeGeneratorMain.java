package org.ludo.main;

public class CodeGeneratorMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		org.ludo.umlgenerator.main.CodeGeneratorMain.main(args);
		org.ludo.codegenerator.main.CodeGeneratorMain.main(args);
	}

}
