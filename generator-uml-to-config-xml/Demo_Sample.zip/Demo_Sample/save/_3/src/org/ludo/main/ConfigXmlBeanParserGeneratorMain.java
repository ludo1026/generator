package org.ludo.main;

public class ConfigXmlBeanParserGeneratorMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		org.ludo.xmlbeangen.ConfigXmlBeanParserGeneratorMain.main(args);
	}

}
