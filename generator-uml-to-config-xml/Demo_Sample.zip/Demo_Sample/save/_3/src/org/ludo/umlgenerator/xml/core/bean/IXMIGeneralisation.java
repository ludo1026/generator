package org.ludo.umlgenerator.xml.core.bean;



public interface IXMIGeneralisation {
	/*
	public static class Manager {
		private static Map mapXMIGeneralisationByTypeParentXmiId = new HashMap();
		private static Map mapXMIGeneralisationByTypeParentGenId = new HashMap();
		private static Map mapXMIGeneralisationByTypeFilleXmiId = new HashMap();
		private static Map mapXMIGeneralisationByTypeFilleGenId = new HashMap();
		public static void addXMIGeneralisationToMap(IXMIGeneralisation generalisation) {
			mapXMIGeneralisationByTypeParentXmiId.put(generalisation.getXmiTypeParent().getXmiId(),generalisation);
			mapXMIGeneralisationByTypeParentGenId.put(generalisation.getXmiTypeParent().getGenId(),generalisation);
			mapXMIGeneralisationByTypeFilleXmiId.put(generalisation.getXmiTypeFille().getXmiId(),generalisation);
			mapXMIGeneralisationByTypeFilleGenId.put(generalisation.getXmiTypeFille().getGenId(),generalisation);
		}
		public static IXMIGeneralisation getXMIGeneralisationFromMapByTypeParentXmiId(String typeParentXmiId) {
			return (IXMIGeneralisation) mapXMIGeneralisationByTypeParentXmiId.get(typeParentXmiId);
		}
		public static IXMIGeneralisation getXMIGeneralisationFromMapByTypeParentGenId(String typeParentGenId) {
			return (IXMIGeneralisation) mapXMIGeneralisationByTypeParentGenId.get(typeParentGenId);
		}
		public static IXMIGeneralisation getXMIGeneralisationFromMapByTypeFilleXmiId(String typeFilleXmiId) {
			return (IXMIGeneralisation) mapXMIGeneralisationByTypeFilleXmiId.get(typeFilleXmiId);
		}
		public static IXMIGeneralisation getXMIGeneralisationFromMapByTypeFilleGenId(String typeFilleGenId) {
			return (IXMIGeneralisation) mapXMIGeneralisationByTypeFilleGenId.get(typeFilleGenId);
		}
	}
	*/

	public IXMIType getXmiTypeParent();

	public IXMIType getXmiTypeEnfant();


}