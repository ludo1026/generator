package org.ludo.umlgenerator.xml.core.bean;

public interface IXMIMultiplicity {
	
	public String getMinimum();
	
	public String getMaximum();
	
}