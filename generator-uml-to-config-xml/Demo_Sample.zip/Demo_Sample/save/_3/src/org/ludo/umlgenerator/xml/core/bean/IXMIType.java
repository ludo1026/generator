package org.ludo.umlgenerator.xml.core.bean;

public interface IXMIType {

}
