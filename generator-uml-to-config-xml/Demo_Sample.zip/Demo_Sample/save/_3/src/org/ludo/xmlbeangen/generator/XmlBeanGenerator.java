package org.ludo.xmlbeangen.generator;

public class XmlBeanGenerator {

}
