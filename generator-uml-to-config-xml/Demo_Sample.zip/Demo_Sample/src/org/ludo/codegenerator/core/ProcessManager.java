/*
 * Projet   : Gen
 * Package  : gen.core
 * Source   : GenerationManager.java
 * Cr�ation : CHABOUD   Date : 29 mars 2007
 * Copyright (C) 2007   Apria RSA
 *
 * --------------- Derni�re mise � jour ---------------------
 * @author  : $author$
 * @version : $Revision$, $Date$
 * --------------- Historique -------------------------------
 * Auteur :                      Date : ../../....
 * Motif  :
 */
package org.ludo.codegenerator.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.ludo.codegenerator.core.gen.bean.ITemplateGeneration;
import org.ludo.codegenerator.core.gen.bean.impl.TemplateGenerationBean;
import org.ludo.codegenerator.core.gen.manager.TemplateGenerationMap;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplates;
import org.ludo.codegenerator.xml.core.gen.core.xmlreader.GenXmlReaderManager;
import org.ludo.utils.AssertHelper;
import org.ludo.utils.LoggerManager;

/**
 * <b>Description :</b>
 * <description de la classe>
 *
 * @version : $Revision$, $Date$
 * @author  : $Author$
 * @since   : version 1.0.0
 */
public class ProcessManager {
    
    private static Logger log = LoggerManager.getLogger(ProcessManager.class);
    
    private String nomFichierConfiguration = null;
    private GenXmlReaderManager genXmlReaderManager = null;
    private IGen gen = null;
    
    public ProcessManager(String nomFichierConfiguration) {
    	this.nomFichierConfiguration = nomFichierConfiguration;
    	genXmlReaderManager = GenXmlReaderManager.getGenXmlReaderManager(nomFichierConfiguration);
    	gen = genXmlReaderManager.getGen();
    	log.debug("genXmlReaderManager = "+genXmlReaderManager);
    }
    
    public void genererFichier() throws Exception {
        try {
            Velocity.init();
            IGenTemplates templates = gen.getGenTemplates();
            if( templates == null ) return;
            IGenClasses classes = gen.getGenClasses();
            if( classes == null ) return;
            IGenGenererGroupe genererGroupe = gen.getGenGenererGroupe();
            if( genererGroupe == null ) return;
            /** Post Gen Process */
            // D�finir le package de chaque classe
            //definirPackagePourClasses(gen.getGenClasses());
            //definirClassePourAssociations(gen.getGenClasses());
            /** Fin Post Gen Process */
            // Par Classes
            IGenGenererParClasses genererParClasses = genererGroupe.getGenGenererParClasses();
            if( genererParClasses != null ) {
                for( Iterator iterGenererParClasse = genererParClasses.getListeGenGenererParClasse().iterator(); iterGenererParClasse.hasNext(); ) {
                	IGenGenererParClasse genererParClasse = (IGenGenererParClasse) iterGenererParClasse.next();
                	IGenClassesRefPourGenererParClasse classesRefPourGenererParClasse = genererParClasse.getGenClassesRefPourGenererParClasse();
                	for( Iterator iterClassesRefPourGenererParClasse = classesRefPourGenererParClasse.getListeGenClasseRefPourGenererParClasse().iterator(); iterClassesRefPourGenererParClasse.hasNext(); ) {
                		IGenClasseRefPourGenererParClasse classeRefPourGenererParClasse = (IGenClasseRefPourGenererParClasse) iterClassesRefPourGenererParClasse.next();
                    	IGenClasse classe = classes.getGenClasseByGenId(classeRefPourGenererParClasse.getClasseGenId());
                    	IGenTemplateGroupesRefPourGenererParClasse templateGroupesRefPourGenererParClasse = genererParClasse.getGenTemplateGroupesRefPourGenererParClasse();
                    	if( classe != null
                    	 && templateGroupesRefPourGenererParClasse != null ) {
                            for( Iterator iterTemplateGroupeRefPourGenererParClasse = templateGroupesRefPourGenererParClasse.getListeGenTemplateGroupeRefPourGenererParClasse().iterator(); iterTemplateGroupeRefPourGenererParClasse.hasNext(); ) {
                            	IGenTemplateGroupeRefPourGenererParClasse templateGroupeRefPourClasse = (IGenTemplateGroupeRefPourGenererParClasse) iterTemplateGroupeRefPourGenererParClasse.next();
                            	IGenTemplateGroupe templateGroupe = gen.getGenTemplateGroupes().getGenTemplateGroupeByNom(templateGroupeRefPourClasse.getTemplateGroupeNom());
                            	if( templateGroupe != null ) {
                            		genererFichierParClasse(templateGroupe, classe);
                            	}
                            }
                    	}
                	}
                }
            }
            // Par St�r�otypes
            /*
            IGenGenererStereotypes genererStereotypes = genererGroupe.getGenGenererStereotypes();
            if( genererStereotypes != null ) {
                for( Iterator iterGenererStereotype = genererStereotypes.getListeGenGenererStereotype().iterator(); iterGenererStereotype.hasNext(); ) {
                	IGenGenererStereotype genererStereotype = (IGenGenererStereotype) iterGenererStereotype.next();
                	IGenStereotypesRefPourGenererStereotype StereotypesRefPourGenererStereotype = genererStereotype.getGenStereotypesRefPourGenererStereotype();
                	for( Iterator iterStereotypesRefPourGenererStereotype = StereotypesRefPourGenererStereotype.getListeGenStereotypeRefPourGenererStereotype().iterator(); iterStereotypesRefPourGenererStereotype.hasNext(); ) {
                		IGenStereotypeRefPourGenererStereotype stereotypeRefPourGenererStereotype = (IGenStereotypeRefPourGenererStereotype) iterStereotypesRefPourGenererStereotype.next();
                		IGenStereotype stereotype = gen.getGenStereotypes().getGenStereotypeByNom(stereotypeRefPourGenererStereotype.getStereotypeNom());
                		if( stereotype != null ) {
	                    	IGenTemplateGroupesRefPourGenererStereotype templateGroupesRefPourGenererStereotype = genererStereotype.getGenTemplateGroupesRefPourGenererStereotype();
	                    	if( templateGroupesRefPourGenererStereotype != null ) {
	                            for( Iterator iterTemplateGroupeRefPourGenererStereotype = templateGroupesRefPourGenererStereotype.getListeGenTemplateGroupeRefPourGenererStereotype().iterator(); iterTemplateGroupeRefPourGenererStereotype.hasNext(); ) {
	                            	IGenTemplateGroupeRefPourGenererStereotype templateGroupeRefPourStereotype = (IGenTemplateGroupeRefPourGenererStereotype) iterTemplateGroupeRefPourGenererStereotype.next();
	                            	IGenTemplateGroupe templateGroupe = gen.getGenTemplateGroupes().getGenTemplateGroupeByNom(templateGroupeRefPourStereotype.getTemplateGroupeNom());
	                            	if( templateGroupe != null ) {
	                            		genererFichierParStereotype(templateGroupe, stereotype);
	                            	}
	                            }
	                    	}
                		}
                	}
                }
            }
            */
            
            IGenGenererParTemplates genererParTemplates = genererGroupe.getGenGenererParTemplates();
            if( genererParTemplates != null ) {
                for( Iterator iterGenererParTemplate = genererParTemplates.getListeGenGenererParTemplate().iterator(); iterGenererParTemplate.hasNext(); ) {
                	IGenGenererParTemplate genererParTemplate = (IGenGenererParTemplate) iterGenererParTemplate.next();
                	IGenTemplateGroupesRefPourGenererParTemplate templateGroupesRefPourGenererParTemplate = genererParTemplate.getGenTemplateGroupesRefPourGenererParTemplate();
                	if( templateGroupesRefPourGenererParTemplate != null ) {
                        for( Iterator iterTemplateGroupeRefPourGenererParTemplate = templateGroupesRefPourGenererParTemplate.getListeGenTemplateGroupeRefPourGenererParTemplate().iterator(); iterTemplateGroupeRefPourGenererParTemplate.hasNext(); ) {
                        	IGenTemplateGroupeRefPourGenererParTemplate templateGroupeRefPourParTemplate = (IGenTemplateGroupeRefPourGenererParTemplate) iterTemplateGroupeRefPourGenererParTemplate.next();
                        	IGenTemplateGroupe templateGroupe = gen.getGenTemplateGroupes().getGenTemplateGroupeByNom(templateGroupeRefPourParTemplate.getTemplateGroupeNom());
                        	if( templateGroupe != null ) {
			                	IGenStereotypesRefPourGenererParTemplate StereotypesRefPourGenererParTemplate = templateGroupeRefPourParTemplate.getGenStereotypesRefPourGenererParTemplate();
			                	List listeStereotype = new ArrayList();
			                	for( Iterator iterStereotypesRefPourGenererParTemplate = StereotypesRefPourGenererParTemplate.getListeGenStereotypeRefPourGenererParTemplate().iterator(); iterStereotypesRefPourGenererParTemplate.hasNext(); ) {
			                		IGenStereotypeRefPourGenererParTemplate stereotypeRefPourGenererParTemplate = (IGenStereotypeRefPourGenererParTemplate) iterStereotypesRefPourGenererParTemplate.next();
			                		IGenStereotype stereotype = gen.getGenStereotypes().getGenStereotypeByNom(stereotypeRefPourGenererParTemplate.getStereotypeNom());
			                		if( stereotype != null ) {
			                			listeStereotype.add(stereotype);
	                            	}
	                            }
                        		genererFichierParTemplate(templateGroupe, listeStereotype);
	                    	}
                		}
                	}
                }
            }
            
            IGenGenererParStereotypes genererParStereotypes = genererGroupe.getGenGenererParStereotypes();
            if( genererParStereotypes != null ) {
                for( Iterator iterGenererParStereotype = genererParStereotypes.getListeGenGenererParStereotype().iterator(); iterGenererParStereotype.hasNext(); ) {
                	IGenGenererParStereotype genererParStereotype = (IGenGenererParStereotype) iterGenererParStereotype.next();
                	IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype = genererParStereotype.getGenStereotypesRefPourGenererParStereotype();
                	List listeStereotype = new ArrayList();
                	for( Iterator iterStereotypeRefPourGenererParStereotype = genStereotypesRefPourGenererParStereotype.getListeGenStereotypeRefPourGenererParStereotype().iterator(); iterStereotypeRefPourGenererParStereotype.hasNext(); ) {
                		IGenStereotypeRefPourGenererParStereotype stereotypeRefPourGenererParStereotype = (IGenStereotypeRefPourGenererParStereotype) iterStereotypeRefPourGenererParStereotype.next();
                		IGenStereotype stereotype = gen.getGenStereotypes().getGenStereotypeByNom(stereotypeRefPourGenererParStereotype.getStereotypeNom());
                		if( stereotype != null ) {
                			IGenTemplateGroupesRefPourGenererParStereotype templateGroupesRefPourGenererParStereotype = stereotypeRefPourGenererParStereotype.getGenTemplateGroupesRefPourGenererParStereotype();
                			if( templateGroupesRefPourGenererParStereotype != null ) {
                				for( Iterator iterTemplateGroupeRefPourGenererParStereotype = templateGroupesRefPourGenererParStereotype.getListeGenTemplateGroupeRefPourGenererParStereotype().iterator(); iterTemplateGroupeRefPourGenererParStereotype.hasNext(); ) {
                					IGenTemplateGroupeRefPourGenererParStereotype templateGroupeRefPourStereotype = (IGenTemplateGroupeRefPourGenererParStereotype) iterTemplateGroupeRefPourGenererParStereotype.next();
                					IGenTemplateGroupe templateGroupe = gen.getGenTemplateGroupes().getGenTemplateGroupeByNom(templateGroupeRefPourStereotype.getTemplateGroupeNom());
                					if( templateGroupe != null ) {
                						genererFichierParStereotype(templateGroupe, stereotype);
                					}
            					}
            				}
            			}
                	}
                }
            }
            
            List listeTemplateGeneration = this.getListeTemplateGeneration();
            processTemplateGeneration(gen, listeTemplateGeneration);
            
            /* Ancien code
            for(Iterator iterGenerer = genererManager.getListeGenerer().iterator(); iterGenerer.hasNext(); ) {
                Generer generer = (Generer) iterGenerer.next();
                Classe classe = classes.getClasse(generer.getNomClasse());
                for(Iterator iterNomTemplate = generer.getListeNomTemplate().iterator(); iterNomTemplate.hasNext(); ) {
                    String nomTemplate = (String) iterNomTemplate.next(); 
                    Template template = templates.getTemplate(nomTemplate);
                    genererFichier(template, classe);
                }
            }
            */
        } catch(Exception e) {
            log.debug(this,e);
            throw e;
        }
    }
    
    private void definirPackagePourClasses(IGenClasses classes) {
    	String packageBase = classes.getPackageBase();
    	List listeGenClasse = classes.getListeGenClasse();
    	for(Iterator iterClasse = listeGenClasse.iterator(); iterClasse.hasNext(); ) {
    		IGenClasse classe = (IGenClasse) iterClasse.next();
    		if( StringUtils.isBlank(packageBase) ) {
    			classe.setPackageJava(classe.getPackageJava());
    		}
    		if( StringUtils.isBlank(classe.getPackageJava()) ) {
    			classe.setPackageJava(packageBase);
    		}
    		if( StringUtils.isNotBlank(packageBase)
    		 && StringUtils.isNotBlank(classe.getPackageJava()) ) {
    			classe.setPackageJava(packageBase + "." + classe.getPackageJava());
    		}
    	}
    }
    /*
    private void definirClassePourAssociations(IGenClasses classes) {
    	List listeGenClasse = classes.getListeGenClasse();
    	for(Iterator iterClasse = listeGenClasse.iterator(); iterClasse.hasNext(); ) {
    		IGenClasse classe = (IGenClasse) iterClasse.next();
    		IGenAssociations associations = classe.getGenAssociations();
        	List listeGenAssociation = associations.getListeGenAssociation();
        	for(Iterator iterAssociation = listeGenAssociation.iterator(); iterAssociation.hasNext(); ) {
        		IGenAssociation association = (IGenAssociation) iterAssociation.next();
        		IGenClasse classeDeAssociation = classes.getGenClasseByNomJava(association.getNomJavaClasse());
       			association.setClasse(classeDeAssociation);
        	}
    	}
    }
    */
    
    private void genererFichierParClasse(IGenTemplateGroupe templateGroupe, IGenClasse classe) {
   		for(Iterator iterTemplateRef = templateGroupe.getListeGenTemplateRef().iterator(); iterTemplateRef.hasNext(); ) {
   			IGenTemplateRef templateRef = (IGenTemplateRef) iterTemplateRef.next();
   			IGenTemplate template = gen.getGenTemplates().getGenTemplateByNom(templateRef.getNom());
   			if( template != null ) {
   				genererFichierParClasse( template, classe );
   			}
    	}
    }
    
    private void genererFichierParClasse(IGenTemplate template, IGenClasse classe) {
        String nomFichierTemplate = 
                    gen.getGenTemplates().getInDir()
            + "/" + template.getFile();
        log.debug("nomFichierTemplate = "+nomFichierTemplate);
        String nomPackage =
			//		gen.getGenTemplates().getPackageJavaBase()
		    //+ "." + 
		    template.getPackageJava().replaceAll("XXX", classe.getPackageJava());
		log.debug("nomPackage = "+nomPackage);
        String nomRepertoireSortie =
        			//gen.getGenTemplates().getOutDir()
            //+ "/" + 
            template.getOutDir()
            + "/" + nomPackage.replaceAll("\\.", "/");
		log.debug("nomRepertoireSortie = "+nomRepertoireSortie);
        String nomFichierSortie = 
                    nomRepertoireSortie
            + "/" + template.getOutFile().replaceAll("XXX", classe.getNomJava());
        log.debug("nomFichierSortie = "+nomFichierSortie);
        String nomElementGenere = 
        	template.getNomElementGenere().replaceAll("XXX", classe.getNomJava() );
        log.debug("nomElementGenere = "+nomElementGenere);
        
        ITemplateGeneration templateGeneration = new TemplateGenerationBean();
        templateGeneration.setNomFichierTemplate(nomFichierTemplate);
        templateGeneration.setNomPackage(nomPackage);
        templateGeneration.setNomElementGenere(nomElementGenere);
        templateGeneration.setNomRepertoireSortie(nomRepertoireSortie);
        templateGeneration.setNomFichierSortie(nomFichierSortie);
        templateGeneration.setGenClasse(classe);
        templateGeneration.setGenTemplate(template);
        this.addTemplateGeneration(templateGeneration);
    }
    
    private void genererFichierParTemplate(IGenTemplateGroupe templateGroupe, List listeStereotype) {
    	// TODO Rechercher les classes
    	Map mapListeClasseParStereotype = new HashMap();
    	for(Iterator iterStereotype = listeStereotype.iterator(); iterStereotype.hasNext(); ) {
    		IGenStereotype stereotype = (IGenStereotype) iterStereotype.next();
	    	ListeClasseParStereotype listeClasseParStereotype = new ListeClasseParStereotype(stereotype);
	    	for(Iterator iterClasse = gen.getGenClasses().getListeGenClasse().iterator(); iterClasse.hasNext(); ) {
	    		IGenClasse classe = (IGenClasse) iterClasse.next();
	    		boolean contientStereotype = false;
	    		if( classe.getGenStereotypesRef() != null
	    		 && classe.getGenStereotypesRef().getListeGenStereotypeRef() != null ) {
		    		for(Iterator iterStereotypeRef = classe.getGenStereotypesRef().getListeGenStereotypeRef().iterator(); iterStereotypeRef.hasNext(); ) {
		    			IGenStereotypeRef stereotypeRef = (IGenStereotypeRef) iterStereotypeRef.next();
		    			if( listeClasseParStereotype.getStereotypeNom().equals(stereotypeRef.getStereotypeNom()) ) {
		    				listeClasseParStereotype.addClasse(classe);
		    			}
		    		}
	    		}
	    	}
	    	if( ! listeClasseParStereotype.getListeClasse().isEmpty() ) {
	    		mapListeClasseParStereotype.put(listeClasseParStereotype.getStereotypeNom(), listeClasseParStereotype);
	    	}
    	}
		genererFichierParTemplate( templateGroupe, mapListeClasseParStereotype );
    }
    
    private void genererFichierParTemplate(IGenTemplateGroupe templateGroupe, Map mapListeClasseParStereotype) {
   		for(Iterator iterTemplateRef = templateGroupe.getListeGenTemplateRef().iterator(); iterTemplateRef.hasNext(); ) {
   			IGenTemplateRef templateRef = (IGenTemplateRef) iterTemplateRef.next();
   			IGenTemplate template = gen.getGenTemplates().getGenTemplateByNom(templateRef.getNom());
   			if( template != null ) {
   				genererFichierParTemplate( template, mapListeClasseParStereotype );
   			}
    	}
    }
    
    private void genererFichierParTemplate(IGenTemplate template, Map mapListeClasseParStereotype) {
        String nomFichierTemplate = 
                    gen.getGenTemplates().getInDir()
            + "/" + template.getFile();
        log.debug("nomFichierTemplate = "+nomFichierTemplate);
        String nomRepertoireSortie =
        			//gen.getGenTemplates().getOutDir()
            // + "/" + 
        	template.getOutDir();
		log.debug("nomRepertoireSortie = "+nomRepertoireSortie);
        String nomFichierSortie = 
                    nomRepertoireSortie
            + "/" + template.getOutFile();
        log.debug("nomFichierSortie = "+nomFichierSortie);
        String nomPackage =
        		//	gen.getGenTemplates().getPackageJavaBase()
            //+ "." + 
            template.getPackageJava();
        log.debug("nomPackage = "+nomPackage);
        String nomElementGenere = 
        	template.getNomElementGenere();
        log.debug("nomElementGenere = "+nomElementGenere);
        //VelocityContext context = new VelocityContext();
        //context.put("", mapListeClasseParStereotype);
        ITemplateGeneration templateGeneration = new TemplateGenerationBean();
        templateGeneration.setNomFichierTemplate(nomFichierTemplate);
        templateGeneration.setNomPackage(nomPackage);
        templateGeneration.setNomElementGenere(nomElementGenere);
        templateGeneration.setNomRepertoireSortie(nomRepertoireSortie);
        templateGeneration.setNomFichierSortie(nomFichierSortie);
        templateGeneration.setMapListeClasseParStereotype(mapListeClasseParStereotype);
        templateGeneration.setGenTemplate(template);
        this.addTemplateGeneration(templateGeneration);
    }
    
    
    
    private void genererFichierParStereotype(IGenTemplateGroupe templateGroupe, IGenStereotype stereotype) {
    	// TODO Rechercher les classes
    	List listeClasse = new ArrayList();
    	for(Iterator iterClasse = gen.getGenClasses().getListeGenClasse().iterator(); iterClasse.hasNext(); ) {
    		IGenClasse classe = (IGenClasse) iterClasse.next();
    		boolean contientStereotype = false;
    		if( classe.getGenStereotypesRef() != null
    		 && classe.getGenStereotypesRef().getListeGenStereotypeRef() != null ) {
	    		for(Iterator iterStereotypeRef = classe.getGenStereotypesRef().getListeGenStereotypeRef().iterator(); iterStereotypeRef.hasNext(); ) {
	    			IGenStereotypeRef stereotypeRef = (IGenStereotypeRef) iterStereotypeRef.next();
	    			if( stereotype.getNom().equals(stereotypeRef.getStereotypeNom()) ) {
	    				listeClasse.add(classe);
	    			}
	    		}
    		}
    	}
    	for(Iterator iterClasse = listeClasse.iterator(); iterClasse.hasNext(); ) {
    		IGenClasse classe = (IGenClasse) iterClasse.next();
    		genererFichierParStereotype( templateGroupe, stereotype, classe );
    	}
    }
    
    private void genererFichierParStereotype(IGenTemplateGroupe templateGroupe, IGenStereotype stereotype, IGenClasse classe) {
   		for(Iterator iterTemplateRef = templateGroupe.getListeGenTemplateRef().iterator(); iterTemplateRef.hasNext(); ) {
   			IGenTemplateRef templateRef = (IGenTemplateRef) iterTemplateRef.next();
   			IGenTemplate template = gen.getGenTemplates().getGenTemplateByNom(templateRef.getNom());
   			if( template != null ) {
   				genererFichierParStereotype( template, stereotype, classe );
   			}
    	}
    }
    
    private void genererFichierParStereotype(IGenTemplate template, IGenStereotype stereotype, IGenClasse classe) {
        String nomFichierTemplate = 
                    gen.getGenTemplates().getInDir()
            + "/" + template.getFile();
        log.debug("nomFichierTemplate = "+nomFichierTemplate);
        String nomPackage =
        		//	gen.getGenTemplates().getPackageJavaBase()
            //+ "." + 
            template.getPackageJava().replaceAll("XXX", classe.getPackageJava());
        log.debug("nomPackage = "+nomPackage);
        String nomRepertoireSortie =
        			//gen.getGenTemplates().getOutDir()
        	//+ "/" + 
        	template.getOutDir()
        	+ "/" + nomPackage.replaceAll("\\.", "/");
        log.debug("nomRepertoireSortie = "+nomRepertoireSortie);
        String nomFichierSortie = 
        			nomRepertoireSortie
        	+ "/" + template.getOutFile().replaceAll("XXX", StringUtils.capitalize(classe.getNomJava()) );
        log.debug("nomFichierSortie = "+nomFichierSortie);
        AssertHelper.assertDefined(template.getNomElementGenere(), "nom de l'�l�ment g�n�r� du template");
        String nomElementGenere = 
        	template.getNomElementGenere().replaceAll("XXX", StringUtils.capitalize(classe.getNomJava()) );
        log.debug("nomElementGenere = "+nomElementGenere);
        ITemplateGeneration templateGeneration = new TemplateGenerationBean();
        templateGeneration.setNomFichierTemplate(nomFichierTemplate);
        templateGeneration.setNomPackage(nomPackage);
        templateGeneration.setNomRepertoireSortie(nomRepertoireSortie);
        templateGeneration.setNomFichierSortie(nomFichierSortie);
        templateGeneration.setNomElementGenere(nomElementGenere);
        templateGeneration.setGenStereotype(stereotype);
        templateGeneration.setGenClasse(classe);
        templateGeneration.setGenTemplate(template);
        this.addTemplateGeneration(templateGeneration);
    }
    
    private List listeTemplateGeneration = new ArrayList();
    
    private void addTemplateGeneration(ITemplateGeneration templateGeneration) {
    	listeTemplateGeneration.add(templateGeneration);
    }
    
    private List getListeTemplateGeneration() {
    	return listeTemplateGeneration;
    }
    
    private static class VelocityUtils {
    	public static void putInContextIfNotNull(VelocityContext context, String nom, Object object) {
    		if(object != null) {
    			context.put(nom, object);
    		}
    	}
    }
    
    private void processTemplateGeneration(IGen gen, List listeTemplateGeneration) throws ResourceNotFoundException, ParseErrorException, MethodInvocationException, Exception {
    	AssertHelper.assertNotNullArgument(listeTemplateGeneration, "liste des TemplateGeneration");
        TemplateGenerationMap templateGenerationMap = TemplateGenerationMap.Manager.getNewTemplateGenerationMap(listeTemplateGeneration);
        for(Iterator iterTemplateGeneration = listeTemplateGeneration.iterator(); iterTemplateGeneration.hasNext(); ) {
    		ITemplateGeneration templateGeneration = (ITemplateGeneration) iterTemplateGeneration.next();
    		
            VelocityContext context = new VelocityContext();
            VelocityUtils.putInContextIfNotNull(context, "templateGenerationMap", templateGenerationMap);
            VelocityUtils.putInContextIfNotNull(context, "SU", StringUtilsInstance.getInstance());
            VelocityUtils.putInContextIfNotNull(context, "StringUtils", StringUtilsInstance.getInstance());
            VelocityUtils.putInContextIfNotNull(context, "stereotype", templateGeneration.getGenStereotype());
            VelocityUtils.putInContextIfNotNull(context, "classe", templateGeneration.getGenClasse());
            VelocityUtils.putInContextIfNotNull(context, "template", templateGeneration.getGenTemplate());
            VelocityUtils.putInContextIfNotNull(context, "nomPackage", templateGeneration.getNomPackage());
           	VelocityUtils.putInContextIfNotNull(context, "mapListeClasseParStereotype", templateGeneration.getMapListeClasseParStereotype());
           	VelocityUtils.putInContextIfNotNull(context, "templateGeneration", templateGeneration);
            
            /* // Test :
            if( templateGeneration.getClasse() != null && templateGeneration.getClasse().getGenAssociations() != null ) {
            	for( Iterator iter = templateGeneration.getClasse().getGenAssociations().getListeGenAssociation().iterator(); iter.hasNext(); ) {
            		IGenAssociation association = (IGenAssociation) iter.next();
            		TemplateGeneration templateGenerationTest = templateGenerationMap.getByNomPackageAndNomClasse("bean_template",gen.getGenTemplates().getPackageJavaBase() + "." + association.getPackageJavaClasse(),association.getNomJavaClasse());
            		boolean est = true;
    			}
			}
			*/
            
            String nomFichierTemplate = templateGeneration.getNomFichierTemplate();
    		String nomRepertoireSortie = templateGeneration.getNomRepertoireSortie();
    		String nomFichierSortie = templateGeneration.getNomFichierSortie();

    		StringWriter w = new StringWriter();
            Velocity.mergeTemplate(nomFichierTemplate, "ISO-8859-1", context, w );
            System.out.println("out = "+w);
            
            // Cr�er le nouveau fichier g�n�r� dans le r�pertoire temporaire de traitement
            File repSortie = new File(nomRepertoireSortie);
            repSortie.mkdirs();
            File repSortieTemp = new File("temp/"+nomRepertoireSortie);
            repSortieTemp.mkdirs();
            File fileSortie = new File(nomFichierSortie);
            if( ! fileSortie.exists() )
            {
	            FileWriter file = new FileWriter(new File(nomFichierSortie));
	            Velocity.mergeTemplate(nomFichierTemplate, "ISO-8859-1", context, file );
	            file.flush();
	            file.close();
            }
            else
            {
	            FileWriter file = new FileWriter(new File("temp/"+nomFichierSortie));
	            Velocity.mergeTemplate(nomFichierTemplate, "ISO-8859-1", context, file );
	            file.flush();
	            file.close();
	            
	            // Table des modifications apport�es dans les zones de modifications
	            Map mapZoneModification = new HashMap();
	            String codeZonePrecedent = null;
	            
	            // Ouvre l'ancien fichier d�j� g�n�r� pour lecture
	            BufferedReader in = new BufferedReader(new FileReader(nomFichierSortie));
	            StringBuffer strBuffer = null;
	            String line = in.readLine();
	            while( line != null ) {
	            	int posZoneDebut = StringUtils.indexOf(line, "@zone-debut:");
	            	int posZoneFin = StringUtils.indexOf(line, "@zone-fin:");
	            	if( posZoneDebut >= 0) {
	            		int posDebutCodeZone = StringUtils.indexOf(line, '{', posZoneDebut) + 1;
	            		AssertHelper.assertBoolean(posDebutCodeZone >= 0,"le code de la zone de modifications n'est pas pr�c�d� d'une accolade.");
	            		int posFinCodeZone = StringUtils.indexOf(line, '}', posDebutCodeZone);
	            		AssertHelper.assertBoolean(posFinCodeZone >= 0,"le code de la zone de modifications n'est pas suivi d'une accolade.");
	            		AssertHelper.assertBoolean(codeZonePrecedent == null, "la zone de modifications pr�c�dente '"+codeZonePrecedent+"' n'est pas termin�e par une balise de fin de zone");
	            		codeZonePrecedent = StringUtils.substring(line, posDebutCodeZone, posFinCodeZone);
	            		AssertHelper.assertDefined(codeZonePrecedent, "code de la zone de modification");
	            		strBuffer = new StringBuffer();
	            	}
	            	else
	            	if( posZoneFin >= 0 ) {
	            		int posDebutCodeZone = StringUtils.indexOf(line, '{', posZoneFin) + 1;
	            		AssertHelper.assertBoolean(posDebutCodeZone >= 0,"le code de la zone de modifications n'est pas pr�c�d� d'une accolade.");
	            		int posFinCodeZone = StringUtils.indexOf(line, '}', posDebutCodeZone);
	            		AssertHelper.assertBoolean(posFinCodeZone >= 0,"le code de la zone de modifications n'est pas suivi d'une accolade.");
	            		String codeZone = StringUtils.substring(line, posDebutCodeZone, posFinCodeZone);
	            		AssertHelper.assertDefined(codeZone, "code de la zone de modification");
	            		AssertHelper.assertBoolean(codeZonePrecedent != null, "aucune balise d'ouverture de zone de modifications '"+codeZone+"' n'a �t� d�finie");
	            		AssertHelper.assertBoolean(StringUtils.equalsIgnoreCase(codeZonePrecedent, codeZone), "le code de la zone de modification dans les balises de d�but et de fin de zone ne sont pas identiques");
	            		mapZoneModification.put(codeZone, strBuffer.toString());
	            		codeZonePrecedent = null;
	            	}
	            	else
	               	if( codeZonePrecedent != null)
	            	{
	               		strBuffer.append(line + "\n");
	            	}
	            	line = in.readLine();
	            }
	            in.close();
	            AssertHelper.assertDefined(codeZonePrecedent == null, "la derni�re zone de modifications n'est pas termin�e par une balise de fin");
	            
	            // Modification du fichier de sortie
	            BufferedWriter out = new BufferedWriter(new FileWriter(nomFichierSortie));
	            in = new BufferedReader(new FileReader("temp/"+nomFichierSortie));
	            line = in.readLine();
	            while( line != null ) {
	            	int posZoneDebut = StringUtils.indexOf(line, "@zone-debut:");
	            	int posZoneFin = StringUtils.indexOf(line, "@zone-fin:");
	            	if( posZoneDebut >= 0) {
	            		int posDebutCodeZone = StringUtils.indexOf(line, '{', posZoneDebut) + 1;
	            		AssertHelper.assertBoolean(posDebutCodeZone >= 0,"le code de la zone de modifications n'est pas pr�c�d� d'une accolade.");
	            		int posFinCodeZone = StringUtils.indexOf(line, '}', posDebutCodeZone);
	            		AssertHelper.assertBoolean(posFinCodeZone >= 0,"le code de la zone de modifications n'est pas suivi d'une accolade.");
	            		AssertHelper.assertBoolean(codeZonePrecedent == null, "la zone de modifications pr�c�dente '"+codeZonePrecedent+"' n'est pas termin�e par une balise de fin de zone");
	            		codeZonePrecedent = StringUtils.substring(line, posDebutCodeZone, posFinCodeZone);
	            		AssertHelper.assertDefined(codeZonePrecedent, "code de la zone de modification");
	            	}
	            	else
	            	if( posZoneFin >= 0 ) {
	            		int posDebutCodeZone = StringUtils.indexOf(line, '{', posZoneFin) + 1;
	            		AssertHelper.assertBoolean(posDebutCodeZone >= 0,"le code de la zone de modifications n'est pas pr�c�d� d'une accolade.");
	            		int posFinCodeZone = StringUtils.indexOf(line, '}', posDebutCodeZone);
	            		AssertHelper.assertBoolean(posFinCodeZone >= 0,"le code de la zone de modifications n'est pas suivi d'une accolade.");
	            		String codeZone = StringUtils.substring(line, posDebutCodeZone, posFinCodeZone);
	            		AssertHelper.assertDefined(codeZone, "code de la zone de modification");
	            		AssertHelper.assertBoolean(codeZonePrecedent != null, "aucune balise d'ouverture de zone de modifications '"+codeZone+"' n'a �t� d�finie");
	            		AssertHelper.assertBoolean(StringUtils.equalsIgnoreCase(codeZonePrecedent, codeZone), "le code de la zone de modification dans les balises de d�but et de fin de zone ne sont pas identiques");
	            		codeZonePrecedent = null;
	            		String contenuZoneModification = (String) mapZoneModification.get(codeZone);
	            		if( contenuZoneModification != null ) {
	            			out.write(contenuZoneModification);
	            		}
	            	}
	            	else
	            	{
	           			AssertHelper.assertBoolean(codeZonePrecedent == null, "la zone de modifications d�finie dans le template ne doit pas contenir de lignes entre la zone de d�but et de fin de la zone '"+codeZonePrecedent+"'");
	            	}
	            	out.write(line);
	            	out.newLine();
	            	line = in.readLine();
	            }
	            out.close();
	            AssertHelper.assertDefined(codeZonePrecedent == null, "la derni�re zone de modifications n'est pas termin�e par une balise de fin");
            }
    	}
    	//deleteDirectory(new File("temp/"));
    }
    
	static private boolean deleteDirectory(File path) { 
		boolean resultat = true; 
		
        if( path.exists() ) { 
        	File[] files = path.listFiles(); 
        	for(int i=0; i<files.length; i++) { 
        		if(files[i].isDirectory()) { 
        	    	deleteDirectory(files[i]); 
        		} 
        		else { 
        	    	AssertHelper.assertBoolean(files[i].delete(), "l'effacement du fichier ne s'est pas correctement d�roul�"); 
        		} 
        	} 
        } 
    	AssertHelper.assertBoolean(path.delete(), "l'effacement du r�pertoire ne s'est pas correctement d�roul�"); 
        return( true ); 
	}
    
    /* Ancien code
    private void genererFichier(Template template, Classe classe) {
        String nomFichierTemplate = 
                    templateManager.getTemplates().getRepertoireEntree()
            + "/" + template.getNomFichierTemplate();
        log.debug("nomFichierTemplate = "+nomFichierTemplate);
        String nomRepertoireSortie =
                    templateManager.getTemplates().getRepertoireSortie()
            + "/" + classe.getJavaPackage().replaceAll("\\.", "/")
            + "/" + template.getNomSousRepertoireSortie();
        String nomFichierSortie = 
                    nomRepertoireSortie
            + "/" + template.getNomFichierSortie().replaceAll("XXX", classe.getJavaNomClasse());
        log.debug("nomFichierSortie = "+nomFichierSortie);
        String nomPackage =
                    templateManager.getTemplates().getPackageBase()
            + "." + classe.getJavaPackage()
            + "." + template.getNomSousPackage();
        log.debug("nomPackage = "+nomPackage);
        VelocityContext context = new VelocityContext();
        context.put("classe", classe);
        context.put("template", template);
        context.put("package", nomPackage);
        
        StringWriter w = new StringWriter();
        Velocity.mergeTemplate(nomFichierTemplate, "ISO-8859-1", context, w );
        System.out.println("out = "+w);
        
        File repSortie = new File(nomRepertoireSortie);
        repSortie.mkdirs();
        FileWriter file = new FileWriter(new File(nomFichierSortie));
        Velocity.mergeTemplate(nomFichierTemplate, "ISO-8859-1", context, file );
        file.flush();
        file.close();
    }
	*/

}
