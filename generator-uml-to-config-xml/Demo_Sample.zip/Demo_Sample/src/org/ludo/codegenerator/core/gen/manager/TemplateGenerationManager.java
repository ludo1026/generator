package org.ludo.codegenerator.core.gen.manager;

import java.util.List;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.utils.AssertHelper;

public class TemplateGenerationManager {
	
	private static TemplateGenerationManager templateGenerationManager = null;
	
	public static TemplateGenerationManager getInstance() {
		AssertHelper.assertDefined(templateGenerationManager, "objet instance de TemplateGenerationManager (doit �tre initialis� par l'appel � sa m�thode 'defineAndGetNewInstance')");
		return templateGenerationManager;
	}
	
	public static TemplateGenerationManager defineAndGetNewInstance(
									IGen gen,
									List listeTemplateGeneration,
									TemplateGenerationMap templateGenerationMap
								)
	{
		templateGenerationManager = 
			new TemplateGenerationManager(
				gen,
				listeTemplateGeneration,
				templateGenerationMap
			);
		return templateGenerationManager;
	}
	
	/**
	 * Instance
	 */
	
	private final IGen gen;
	private final List listeTemplateGeneration;
	private final TemplateGenerationMap templateGenerationMap;

	private TemplateGenerationManager(
							IGen gen,
							List listeTemplateGeneration,
							TemplateGenerationMap templateGenerationMap
						)
	{
		AssertHelper.assertDefined(gen, "objet racine des beans de lecture du fichier config.xml de g�n�ration du code");
		this.gen = gen;
		AssertHelper.assertDefined(listeTemplateGeneration, "liste des beans de g�n�ration de template");
		this.listeTemplateGeneration = listeTemplateGeneration;
		AssertHelper.assertDefined(templateGenerationMap, "table des beans de g�n�ration de template");
		this.templateGenerationMap = templateGenerationMap;
	}
	
	public IGen getGen() {
		return gen;
	}

	public List getListeTemplateGeneration() {
		return listeTemplateGeneration;
	}

	public TemplateGenerationMap getTemplateGenerationMap() {
		return templateGenerationMap;
	}
	
}
