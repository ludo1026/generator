package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGen {
	
	/** Récupération de l'élément parent */
	
	/** Récupération des éléments fils */

    public IGenTemplates getGenTemplates();
    
    public void setGenTemplates(IGenTemplates genTemplates);
	

    public IGenTemplateGroupes getGenTemplateGroupes();
    
    public void setGenTemplateGroupes(IGenTemplateGroupes genTemplateGroupes);
	

    public IGenStereotypes getGenStereotypes();
    
    public void setGenStereotypes(IGenStereotypes genStereotypes);
	

    public IGenClasses getGenClasses();
    
    public void setGenClasses(IGenClasses genClasses);
	

    public IGenGenererGroupe getGenGenererGroupe();
    
    public void setGenGenererGroupe(IGenGenererGroupe genGenererGroupe);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
