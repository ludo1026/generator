package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenAssociations {
	
	/** Récupération de l'élément parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** Récupération des éléments fils */
	
    public IGenAssociation getGenAssociationByGenId(String genId);
    public IGenAssociation getGenAssociationByNomJavaChamp(String nomJavaChamp);
    public IGenAssociation getGenAssociationByClasseGenId(String classeGenId);
    public IGenAssociation getGenAssociationByNombreMinimum(String nombreMinimum);
    public IGenAssociation getGenAssociationByNombreMaximum(String nombreMaximum);
    public void addGenAssociation(IGenAssociation genAssociation);
    public List getListeGenAssociation();
    public void setListeGenAssociation(List listeGenAssociation);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
