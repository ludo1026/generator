package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenAttributs {
	
	/** Récupération de l'élément parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** Récupération des éléments fils */
	
    public IGenAttribut getGenAttributByGenId(String genId);
    public IGenAttribut getGenAttributByNomJava(String nomJava);
    public IGenAttribut getGenAttributByType(String type);
    public IGenAttribut getGenAttributByNombreMinimum(String nombreMinimum);
    public IGenAttribut getGenAttributByNombreMaximum(String nombreMaximum);
    public IGenAttribut getGenAttributByNomSQL(String nomSQL);
    public IGenAttribut getGenAttributByTypeSQL(String typeSQL);
    public IGenAttribut getGenAttributByEstDansTable(String estDansTable);
    public IGenAttribut getGenAttributBySize(String size);
    public IGenAttribut getGenAttributByEstClePrimaire(String estClePrimaire);
    public IGenAttribut getGenAttributByEstCleIncrementee(String estCleIncrementee);
    public void addGenAttribut(IGenAttribut genAttribut);
    public List getListeGenAttribut();
    public void setListeGenAttribut(List listeGenAttribut);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
