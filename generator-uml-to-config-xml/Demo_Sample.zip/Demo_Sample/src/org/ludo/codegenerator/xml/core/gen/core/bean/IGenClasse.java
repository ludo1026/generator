package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClasse {
	
	/** Récupération de l'élément parent */
	
	public IGenClasses getReferenceGenClasses();
	
	public void setReferenceGenClasses(IGenClasses referenceGenClasses);
	
	/** Récupération des éléments fils */

    public IGenAttributs getGenAttributs();
    
    public void setGenAttributs(IGenAttributs genAttributs);
	

    public IGenMethodes getGenMethodes();
    
    public void setGenMethodes(IGenMethodes genMethodes);
	

    public IGenStereotypesRef getGenStereotypesRef();
    
    public void setGenStereotypesRef(IGenStereotypesRef genStereotypesRef);
	

    public IGenAssociations getGenAssociations();
    
    public void setGenAssociations(IGenAssociations genAssociations);
	

    public IGenClasseParents getGenClasseParents();
    
    public void setGenClasseParents(IGenClasseParents genClasseParents);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	public String getGenIdAsString();
	public void setGenIdAsString(String genIdAsString);
	
	public String getNomJavaAsString();
	public void setNomJavaAsString(String nomJavaAsString);
	
	public String getPackageJavaAsString();
	public void setPackageJavaAsString(String packageJavaAsString);
	
	public String getNomTableAsString();
	public void setNomTableAsString(String nomTableAsString);
	
	public String getNomVueAsString();
	public void setNomVueAsString(String nomVueAsString);
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	

	public String getGenId();
	public void setGenId(String genId);

	public String getNomJava();
	public void setNomJava(String nomJava);

	public String getPackageJava();
	public void setPackageJava(String packageJava);

	public String getNomTable();
	public void setNomTable(String nomTable);

	public String getNomVue();
	public void setNomVue(String nomVue);
}
