package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClasseParents {
	
	/** Récupération de l'élément parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** Récupération des éléments fils */
	
    public IGenClasseParent getGenClasseParentByClasseGenId(String classeGenId);
    public void addGenClasseParent(IGenClasseParent genClasseParent);
    public List getListeGenClasseParent();
    public void setListeGenClasseParent(List listeGenClasseParent);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
