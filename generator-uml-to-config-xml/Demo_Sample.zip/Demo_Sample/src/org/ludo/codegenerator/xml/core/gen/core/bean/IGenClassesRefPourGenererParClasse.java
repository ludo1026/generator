package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenClassesRefPourGenererParClasse {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParClasse getReferenceGenGenererParClasse();
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse);
	
	/** Récupération des éléments fils */
	
    public IGenClasseRefPourGenererParClasse getGenClasseRefPourGenererParClasseByClasseGenId(String classeGenId);
    public void addGenClasseRefPourGenererParClasse(IGenClasseRefPourGenererParClasse genClasseRefPourGenererParClasse);
    public List getListeGenClasseRefPourGenererParClasse();
    public void setListeGenClasseRefPourGenererParClasse(List listeGenClasseRefPourGenererParClasse);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
