package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererGroupe {
	
	/** Récupération de l'élément parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** Récupération des éléments fils */

    public IGenGenererParClasses getGenGenererParClasses();
    
    public void setGenGenererParClasses(IGenGenererParClasses genGenererParClasses);
	

    public IGenGenererParTemplates getGenGenererParTemplates();
    
    public void setGenGenererParTemplates(IGenGenererParTemplates genGenererParTemplates);
	

    public IGenGenererParStereotypes getGenGenererParStereotypes();
    
    public void setGenGenererParStereotypes(IGenGenererParStereotypes genGenererParStereotypes);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
