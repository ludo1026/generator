package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParClasse {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParClasses getReferenceGenGenererParClasses();
	
	public void setReferenceGenGenererParClasses(IGenGenererParClasses referenceGenGenererParClasses);
	
	/** Récupération des éléments fils */

    public IGenClassesRefPourGenererParClasse getGenClassesRefPourGenererParClasse();
    
    public void setGenClassesRefPourGenererParClasse(IGenClassesRefPourGenererParClasse genClassesRefPourGenererParClasse);
	

    public IGenTemplateGroupesRefPourGenererParClasse getGenTemplateGroupesRefPourGenererParClasse();
    
    public void setGenTemplateGroupesRefPourGenererParClasse(IGenTemplateGroupesRefPourGenererParClasse genTemplateGroupesRefPourGenererParClasse);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
