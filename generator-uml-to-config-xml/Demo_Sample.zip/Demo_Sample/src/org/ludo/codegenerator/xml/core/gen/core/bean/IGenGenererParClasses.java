package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParClasses {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererGroupe getReferenceGenGenererGroupe();
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe);
	
	/** Récupération des éléments fils */
	
    public void addGenGenererParClasse(IGenGenererParClasse genGenererParClasse);
    public List getListeGenGenererParClasse();
    public void setListeGenGenererParClasse(List listeGenGenererParClasse);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
