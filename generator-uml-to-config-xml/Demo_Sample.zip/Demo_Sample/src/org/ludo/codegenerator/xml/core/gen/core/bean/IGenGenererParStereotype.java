package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParStereotypes getReferenceGenGenererParStereotypes();
	
	public void setReferenceGenGenererParStereotypes(IGenGenererParStereotypes referenceGenGenererParStereotypes);
	
	/** Récupération des éléments fils */

    public IGenStereotypesRefPourGenererParStereotype getGenStereotypesRefPourGenererParStereotype();
    
    public void setGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
