package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParStereotypes {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererGroupe getReferenceGenGenererGroupe();
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe);
	
	/** Récupération des éléments fils */
	
    public void addGenGenererParStereotype(IGenGenererParStereotype genGenererParStereotype);
    public List getListeGenGenererParStereotype();
    public void setListeGenGenererParStereotype(List listeGenGenererParStereotype);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
