package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParTemplates getReferenceGenGenererParTemplates();
	
	public void setReferenceGenGenererParTemplates(IGenGenererParTemplates referenceGenGenererParTemplates);
	
	/** Récupération des éléments fils */

    public IGenTemplateGroupesRefPourGenererParTemplate getGenTemplateGroupesRefPourGenererParTemplate();
    
    public void setGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
