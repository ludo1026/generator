package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenMethodes {
	
	/** Récupération de l'élément parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** Récupération des éléments fils */
	
    public IGenMethode getGenMethodeByGenId(String genId);
    public IGenMethode getGenMethodeByNomJava(String nomJava);
    public IGenMethode getGenMethodeByRetourType(String retourType);
    public void addGenMethode(IGenMethode genMethode);
    public List getListeGenMethode();
    public void setListeGenMethode(List listeGenMethode);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
