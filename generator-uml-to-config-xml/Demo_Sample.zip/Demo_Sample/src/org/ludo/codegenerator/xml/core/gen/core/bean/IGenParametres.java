package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenParametres {
	
	/** Récupération de l'élément parent */
	
	public IGenMethode getReferenceGenMethode();
	
	public void setReferenceGenMethode(IGenMethode referenceGenMethode);
	
	/** Récupération des éléments fils */
	
    public IGenParametre getGenParametreByGenId(String genId);
    public IGenParametre getGenParametreByNomJava(String nomJava);
    public IGenParametre getGenParametreByType(String type);
    public void addGenParametre(IGenParametre genParametre);
    public List getListeGenParametre();
    public void setListeGenParametre(List listeGenParametre);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
