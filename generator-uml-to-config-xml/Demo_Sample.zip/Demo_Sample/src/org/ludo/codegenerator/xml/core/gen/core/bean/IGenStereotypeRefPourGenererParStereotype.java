package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypeRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	public IGenStereotypesRefPourGenererParStereotype getReferenceGenStereotypesRefPourGenererParStereotype();
	
	public void setReferenceGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype referenceGenStereotypesRefPourGenererParStereotype);
	
	/** Récupération des éléments fils */

    public IGenTemplateGroupesRefPourGenererParStereotype getGenTemplateGroupesRefPourGenererParStereotype();
    
    public void setGenTemplateGroupesRefPourGenererParStereotype(IGenTemplateGroupesRefPourGenererParStereotype genTemplateGroupesRefPourGenererParStereotype);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	public String getStereotypeNomAsString();
	public void setStereotypeNomAsString(String stereotypeNomAsString);
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	

	public String getStereotypeNom();
	public void setStereotypeNom(String stereotypeNom);
}
