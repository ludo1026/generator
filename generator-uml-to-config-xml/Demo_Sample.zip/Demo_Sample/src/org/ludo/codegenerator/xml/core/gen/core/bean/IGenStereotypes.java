package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypes {
	
	/** Récupération de l'élément parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** Récupération des éléments fils */
	
    public IGenStereotype getGenStereotypeByNom(String nom);
    public void addGenStereotype(IGenStereotype genStereotype);
    public List getListeGenStereotype();
    public void setListeGenStereotype(List listeGenStereotype);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
