package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRef {
	
	/** Récupération de l'élément parent */
	
	public IGenClasse getReferenceGenClasse();
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse);
	
	/** Récupération des éléments fils */
	
    public IGenStereotypeRef getGenStereotypeRefByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRef(IGenStereotypeRef genStereotypeRef);
    public List getListeGenStereotypeRef();
    public void setListeGenStereotypeRef(List listeGenStereotypeRef);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
