package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParStereotype getReferenceGenGenererParStereotype();
	
	public void setReferenceGenGenererParStereotype(IGenGenererParStereotype referenceGenGenererParStereotype);
	
	/** Récupération des éléments fils */
	
    public IGenStereotypeRefPourGenererParStereotype getGenStereotypeRefPourGenererParStereotypeByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype genStereotypeRefPourGenererParStereotype);
    public List getListeGenStereotypeRefPourGenererParStereotype();
    public void setListeGenStereotypeRefPourGenererParStereotype(List listeGenStereotypeRefPourGenererParStereotype);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
