package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenStereotypesRefPourGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	public IGenTemplateGroupeRefPourGenererParTemplate getReferenceGenTemplateGroupeRefPourGenererParTemplate();
	
	public void setReferenceGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate);
	
	/** Récupération des éléments fils */
	
    public IGenStereotypeRefPourGenererParTemplate getGenStereotypeRefPourGenererParTemplateByStereotypeNom(String stereotypeNom);
    public void addGenStereotypeRefPourGenererParTemplate(IGenStereotypeRefPourGenererParTemplate genStereotypeRefPourGenererParTemplate);
    public List getListeGenStereotypeRefPourGenererParTemplate();
    public void setListeGenStereotypeRefPourGenererParTemplate(List listeGenStereotypeRefPourGenererParTemplate);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
