package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupe {
	
	/** Récupération de l'élément parent */
	
	public IGenTemplateGroupes getReferenceGenTemplateGroupes();
	
	public void setReferenceGenTemplateGroupes(IGenTemplateGroupes referenceGenTemplateGroupes);
	
	/** Récupération des éléments fils */
	
    public IGenTemplateRef getGenTemplateRefByNom(String nom);
    public void addGenTemplateRef(IGenTemplateRef genTemplateRef);
    public List getListeGenTemplateRef();
    public void setListeGenTemplateRef(List listeGenTemplateRef);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	public String getNomAsString();
	public void setNomAsString(String nomAsString);
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	

	public String getNom();
	public void setNom(String nom);
}
