package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupeRefPourGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	public IGenTemplateGroupesRefPourGenererParTemplate getReferenceGenTemplateGroupesRefPourGenererParTemplate();
	
	public void setReferenceGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate referenceGenTemplateGroupesRefPourGenererParTemplate);
	
	/** Récupération des éléments fils */

    public IGenStereotypesRefPourGenererParTemplate getGenStereotypesRefPourGenererParTemplate();
    
    public void setGenStereotypesRefPourGenererParTemplate(IGenStereotypesRefPourGenererParTemplate genStereotypesRefPourGenererParTemplate);
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	public String getTemplateGroupeNomAsString();
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString);
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	

	public String getTemplateGroupeNom();
	public void setTemplateGroupeNom(String templateGroupeNom);
}
