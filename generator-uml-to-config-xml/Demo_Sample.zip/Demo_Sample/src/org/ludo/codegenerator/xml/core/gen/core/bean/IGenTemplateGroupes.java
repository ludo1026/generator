package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupes {
	
	/** Récupération de l'élément parent */
	
	public IGen getReferenceGen();
	
	public void setReferenceGen(IGen referenceGen);
	
	/** Récupération des éléments fils */
	
    public IGenTemplateGroupe getGenTemplateGroupeByNom(String nom);
    public void addGenTemplateGroupe(IGenTemplateGroupe genTemplateGroupe);
    public List getListeGenTemplateGroupe();
    public void setListeGenTemplateGroupe(List listeGenTemplateGroupe);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
