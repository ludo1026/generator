package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParClasse {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParClasse getReferenceGenGenererParClasse();
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse);
	
	/** Récupération des éléments fils */
	
    public IGenTemplateGroupeRefPourGenererParClasse getGenTemplateGroupeRefPourGenererParClasseByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParClasse(IGenTemplateGroupeRefPourGenererParClasse genTemplateGroupeRefPourGenererParClasse);
    public List getListeGenTemplateGroupeRefPourGenererParClasse();
    public void setListeGenTemplateGroupeRefPourGenererParClasse(List listeGenTemplateGroupeRefPourGenererParClasse);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
