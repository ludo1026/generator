package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	public IGenStereotypeRefPourGenererParStereotype getReferenceGenStereotypeRefPourGenererParStereotype();
	
	public void setReferenceGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype);
	
	/** Récupération des éléments fils */
	
    public IGenTemplateGroupeRefPourGenererParStereotype getGenTemplateGroupeRefPourGenererParStereotypeByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParStereotype(IGenTemplateGroupeRefPourGenererParStereotype genTemplateGroupeRefPourGenererParStereotype);
    public List getListeGenTemplateGroupeRefPourGenererParStereotype();
    public void setListeGenTemplateGroupeRefPourGenererParStereotype(List listeGenTemplateGroupeRefPourGenererParStereotype);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
