package org.ludo.codegenerator.xml.core.gen.core.bean;

import java.util.List;

public interface IGenTemplateGroupesRefPourGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	public IGenGenererParTemplate getReferenceGenGenererParTemplate();
	
	public void setReferenceGenGenererParTemplate(IGenGenererParTemplate referenceGenGenererParTemplate);
	
	/** Récupération des éléments fils */
	
    public IGenTemplateGroupeRefPourGenererParTemplate getGenTemplateGroupeRefPourGenererParTemplateByTemplateGroupeNom(String templateGroupeNom);
    public void addGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate genTemplateGroupeRefPourGenererParTemplate);
    public List getListeGenTemplateGroupeRefPourGenererParTemplate();
    public void setListeGenTemplateGroupeRefPourGenererParTemplate(List listeGenTemplateGroupeRefPourGenererParTemplate);
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
