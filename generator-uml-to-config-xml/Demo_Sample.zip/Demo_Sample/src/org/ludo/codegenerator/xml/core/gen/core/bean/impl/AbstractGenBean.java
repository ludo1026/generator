package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenBean implements IGen {
	
	/** Récupération de l'élément parent */
	
	/** Récupération des éléments fils */

    private IGenTemplates genTemplates = null;
    
    public IGenTemplates getGenTemplates() {
    	return this.genTemplates;
    }
    
    public void setGenTemplates(IGenTemplates genTemplates) {
    	genTemplates.setReferenceGen(this);
    	this.genTemplates = genTemplates;
    }
	

    private IGenTemplateGroupes genTemplateGroupes = null;
    
    public IGenTemplateGroupes getGenTemplateGroupes() {
    	return this.genTemplateGroupes;
    }
    
    public void setGenTemplateGroupes(IGenTemplateGroupes genTemplateGroupes) {
    	genTemplateGroupes.setReferenceGen(this);
    	this.genTemplateGroupes = genTemplateGroupes;
    }
	

    private IGenStereotypes genStereotypes = null;
    
    public IGenStereotypes getGenStereotypes() {
    	return this.genStereotypes;
    }
    
    public void setGenStereotypes(IGenStereotypes genStereotypes) {
    	genStereotypes.setReferenceGen(this);
    	this.genStereotypes = genStereotypes;
    }
	

    private IGenClasses genClasses = null;
    
    public IGenClasses getGenClasses() {
    	return this.genClasses;
    }
    
    public void setGenClasses(IGenClasses genClasses) {
    	genClasses.setReferenceGen(this);
    	this.genClasses = genClasses;
    }
	

    private IGenGenererGroupe genGenererGroupe = null;
    
    public IGenGenererGroupe getGenGenererGroupe() {
    	return this.genGenererGroupe;
    }
    
    public void setGenGenererGroupe(IGenGenererGroupe genGenererGroupe) {
    	genGenererGroupe.setReferenceGen(this);
    	this.genGenererGroupe = genGenererGroupe;
    }
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
