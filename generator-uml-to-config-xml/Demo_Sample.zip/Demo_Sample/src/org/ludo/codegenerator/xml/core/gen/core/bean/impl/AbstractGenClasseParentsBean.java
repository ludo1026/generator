package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseParents;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseParent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenClasseParentsBean implements IGenClasseParents {
	
	/** Récupération de l'élément parent */
	
	private IGenClasse referenceGenClasse = null;
	
	public IGenClasse getReferenceGenClasse() {
		return referenceGenClasse;
	}
	
	public void setReferenceGenClasse(IGenClasse referenceGenClasse) {
		this.referenceGenClasse = referenceGenClasse;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenClasseParent = new ArrayList();
	
    public IGenClasseParent getGenClasseParentByClasseGenId(String classeGenId) {
        for(Iterator iter = listeGenClasseParent.iterator(); iter.hasNext(); ) {
            GenClasseParentBean genClasseParent = (GenClasseParentBean) iter.next();
            if(genClasseParent.getClasseGenId().equalsIgnoreCase(classeGenId)) {
                return genClasseParent;
            }
        }
        throw new IllegalStateException("La genClasseParent n'est pas définie : classeGenId de genClasseParent = "+classeGenId);
    }
    public void addGenClasseParent(IGenClasseParent genClasseParent) {
    	genClasseParent.setReferenceGenClasseParents(this);
        listeGenClasseParent.add(genClasseParent);
    }
    public List getListeGenClasseParent() {
        return listeGenClasseParent;
    }
    public void setListeGenClasseParent(List listeGenClasseParent) {
        this.listeGenClasseParent = listeGenClasseParent;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
