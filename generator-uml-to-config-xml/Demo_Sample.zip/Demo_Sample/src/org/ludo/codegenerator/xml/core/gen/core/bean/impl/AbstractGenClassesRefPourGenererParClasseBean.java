package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseRefPourGenererParClasse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenClassesRefPourGenererParClasseBean implements IGenClassesRefPourGenererParClasse {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererParClasse referenceGenGenererParClasse = null;
	
	public IGenGenererParClasse getReferenceGenGenererParClasse() {
		return referenceGenGenererParClasse;
	}
	
	public void setReferenceGenGenererParClasse(IGenGenererParClasse referenceGenGenererParClasse) {
		this.referenceGenGenererParClasse = referenceGenGenererParClasse;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenClasseRefPourGenererParClasse = new ArrayList();
	
    public IGenClasseRefPourGenererParClasse getGenClasseRefPourGenererParClasseByClasseGenId(String classeGenId) {
        for(Iterator iter = listeGenClasseRefPourGenererParClasse.iterator(); iter.hasNext(); ) {
            GenClasseRefPourGenererParClasseBean genClasseRefPourGenererParClasse = (GenClasseRefPourGenererParClasseBean) iter.next();
            if(genClasseRefPourGenererParClasse.getClasseGenId().equalsIgnoreCase(classeGenId)) {
                return genClasseRefPourGenererParClasse;
            }
        }
        throw new IllegalStateException("La genClasseRefPourGenererParClasse n'est pas définie : classeGenId de genClasseRefPourGenererParClasse = "+classeGenId);
    }
    public void addGenClasseRefPourGenererParClasse(IGenClasseRefPourGenererParClasse genClasseRefPourGenererParClasse) {
    	genClasseRefPourGenererParClasse.setReferenceGenClassesRefPourGenererParClasse(this);
        listeGenClasseRefPourGenererParClasse.add(genClasseRefPourGenererParClasse);
    }
    public List getListeGenClasseRefPourGenererParClasse() {
        return listeGenClasseRefPourGenererParClasse;
    }
    public void setListeGenClasseRefPourGenererParClasse(List listeGenClasseRefPourGenererParClasse) {
        this.listeGenClasseRefPourGenererParClasse = listeGenClasseRefPourGenererParClasse;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
