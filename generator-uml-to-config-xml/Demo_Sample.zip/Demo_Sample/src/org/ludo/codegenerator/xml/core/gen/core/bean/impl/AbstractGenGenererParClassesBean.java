package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenGenererParClassesBean implements IGenGenererParClasses {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererGroupe referenceGenGenererGroupe = null;
	
	public IGenGenererGroupe getReferenceGenGenererGroupe() {
		return referenceGenGenererGroupe;
	}
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe) {
		this.referenceGenGenererGroupe = referenceGenGenererGroupe;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenGenererParClasse = new ArrayList();
	
    public void addGenGenererParClasse(IGenGenererParClasse genGenererParClasse) {
    	genGenererParClasse.setReferenceGenGenererParClasses(this);
        listeGenGenererParClasse.add(genGenererParClasse);
    }
    public List getListeGenGenererParClasse() {
        return listeGenGenererParClasse;
    }
    public void setListeGenGenererParClasse(List listeGenGenererParClasse) {
        this.listeGenGenererParClasse = listeGenGenererParClasse;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
