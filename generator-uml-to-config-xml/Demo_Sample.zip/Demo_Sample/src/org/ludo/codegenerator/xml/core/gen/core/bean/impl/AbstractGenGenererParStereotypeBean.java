package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenGenererParStereotypeBean implements IGenGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererParStereotypes referenceGenGenererParStereotypes = null;
	
	public IGenGenererParStereotypes getReferenceGenGenererParStereotypes() {
		return referenceGenGenererParStereotypes;
	}
	
	public void setReferenceGenGenererParStereotypes(IGenGenererParStereotypes referenceGenGenererParStereotypes) {
		this.referenceGenGenererParStereotypes = referenceGenGenererParStereotypes;
	}
	
	/** Récupération des éléments fils */

    private IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype = null;
    
    public IGenStereotypesRefPourGenererParStereotype getGenStereotypesRefPourGenererParStereotype() {
    	return this.genStereotypesRefPourGenererParStereotype;
    }
    
    public void setGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype genStereotypesRefPourGenererParStereotype) {
    	genStereotypesRefPourGenererParStereotype.setReferenceGenGenererParStereotype(this);
    	this.genStereotypesRefPourGenererParStereotype = genStereotypesRefPourGenererParStereotype;
    }
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
