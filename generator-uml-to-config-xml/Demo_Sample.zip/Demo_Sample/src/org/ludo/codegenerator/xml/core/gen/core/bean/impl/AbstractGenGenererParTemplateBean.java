package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenGenererParTemplateBean implements IGenGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererParTemplates referenceGenGenererParTemplates = null;
	
	public IGenGenererParTemplates getReferenceGenGenererParTemplates() {
		return referenceGenGenererParTemplates;
	}
	
	public void setReferenceGenGenererParTemplates(IGenGenererParTemplates referenceGenGenererParTemplates) {
		this.referenceGenGenererParTemplates = referenceGenGenererParTemplates;
	}
	
	/** Récupération des éléments fils */

    private IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate = null;
    
    public IGenTemplateGroupesRefPourGenererParTemplate getGenTemplateGroupesRefPourGenererParTemplate() {
    	return this.genTemplateGroupesRefPourGenererParTemplate;
    }
    
    public void setGenTemplateGroupesRefPourGenererParTemplate(IGenTemplateGroupesRefPourGenererParTemplate genTemplateGroupesRefPourGenererParTemplate) {
    	genTemplateGroupesRefPourGenererParTemplate.setReferenceGenGenererParTemplate(this);
    	this.genTemplateGroupesRefPourGenererParTemplate = genTemplateGroupesRefPourGenererParTemplate;
    }
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
