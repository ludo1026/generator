package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenGenererParTemplatesBean implements IGenGenererParTemplates {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererGroupe referenceGenGenererGroupe = null;
	
	public IGenGenererGroupe getReferenceGenGenererGroupe() {
		return referenceGenGenererGroupe;
	}
	
	public void setReferenceGenGenererGroupe(IGenGenererGroupe referenceGenGenererGroupe) {
		this.referenceGenGenererGroupe = referenceGenGenererGroupe;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenGenererParTemplate = new ArrayList();
	
    public void addGenGenererParTemplate(IGenGenererParTemplate genGenererParTemplate) {
    	genGenererParTemplate.setReferenceGenGenererParTemplates(this);
        listeGenGenererParTemplate.add(genGenererParTemplate);
    }
    public List getListeGenGenererParTemplate() {
        return listeGenGenererParTemplate;
    }
    public void setListeGenGenererParTemplate(List listeGenGenererParTemplate) {
        this.listeGenGenererParTemplate = listeGenGenererParTemplate;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
