package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenStereotypeRefPourGenererParStereotypeBean implements IGenStereotypeRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	private IGenStereotypesRefPourGenererParStereotype referenceGenStereotypesRefPourGenererParStereotype = null;
	
	public IGenStereotypesRefPourGenererParStereotype getReferenceGenStereotypesRefPourGenererParStereotype() {
		return referenceGenStereotypesRefPourGenererParStereotype;
	}
	
	public void setReferenceGenStereotypesRefPourGenererParStereotype(IGenStereotypesRefPourGenererParStereotype referenceGenStereotypesRefPourGenererParStereotype) {
		this.referenceGenStereotypesRefPourGenererParStereotype = referenceGenStereotypesRefPourGenererParStereotype;
	}
	
	/** Récupération des éléments fils */

    private IGenTemplateGroupesRefPourGenererParStereotype genTemplateGroupesRefPourGenererParStereotype = null;
    
    public IGenTemplateGroupesRefPourGenererParStereotype getGenTemplateGroupesRefPourGenererParStereotype() {
    	return this.genTemplateGroupesRefPourGenererParStereotype;
    }
    
    public void setGenTemplateGroupesRefPourGenererParStereotype(IGenTemplateGroupesRefPourGenererParStereotype genTemplateGroupesRefPourGenererParStereotype) {
    	genTemplateGroupesRefPourGenererParStereotype.setReferenceGenStereotypeRefPourGenererParStereotype(this);
    	this.genTemplateGroupesRefPourGenererParStereotype = genTemplateGroupesRefPourGenererParStereotype;
    }
	
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	

	public String getStereotypeNomAsString() {
		return this.stereotypeNom;
	}
	public void setStereotypeNomAsString(String stereotypeNomAsString) {
		this.stereotypeNom = stereotypeNomAsString;
	}
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
	private String stereotypeNom = null;

	public String getStereotypeNom() {
		return this.stereotypeNom;
	}
	public void setStereotypeNom(String stereotypeNom) {
		this.stereotypeNom = stereotypeNom;
	}
}
