package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParTemplate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenStereotypesRefPourGenererParTemplateBean implements IGenStereotypesRefPourGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	private IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate = null;
	
	public IGenTemplateGroupeRefPourGenererParTemplate getReferenceGenTemplateGroupeRefPourGenererParTemplate() {
		return referenceGenTemplateGroupeRefPourGenererParTemplate;
	}
	
	public void setReferenceGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate referenceGenTemplateGroupeRefPourGenererParTemplate) {
		this.referenceGenTemplateGroupeRefPourGenererParTemplate = referenceGenTemplateGroupeRefPourGenererParTemplate;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenStereotypeRefPourGenererParTemplate = new ArrayList();
	
    public IGenStereotypeRefPourGenererParTemplate getGenStereotypeRefPourGenererParTemplateByStereotypeNom(String stereotypeNom) {
        for(Iterator iter = listeGenStereotypeRefPourGenererParTemplate.iterator(); iter.hasNext(); ) {
            GenStereotypeRefPourGenererParTemplateBean genStereotypeRefPourGenererParTemplate = (GenStereotypeRefPourGenererParTemplateBean) iter.next();
            if(genStereotypeRefPourGenererParTemplate.getStereotypeNom().equalsIgnoreCase(stereotypeNom)) {
                return genStereotypeRefPourGenererParTemplate;
            }
        }
        throw new IllegalStateException("La genStereotypeRefPourGenererParTemplate n'est pas définie : stereotypeNom de genStereotypeRefPourGenererParTemplate = "+stereotypeNom);
    }
    public void addGenStereotypeRefPourGenererParTemplate(IGenStereotypeRefPourGenererParTemplate genStereotypeRefPourGenererParTemplate) {
    	genStereotypeRefPourGenererParTemplate.setReferenceGenStereotypesRefPourGenererParTemplate(this);
        listeGenStereotypeRefPourGenererParTemplate.add(genStereotypeRefPourGenererParTemplate);
    }
    public List getListeGenStereotypeRefPourGenererParTemplate() {
        return listeGenStereotypeRefPourGenererParTemplate;
    }
    public void setListeGenStereotypeRefPourGenererParTemplate(List listeGenStereotypeRefPourGenererParTemplate) {
        this.listeGenStereotypeRefPourGenererParTemplate = listeGenStereotypeRefPourGenererParTemplate;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
