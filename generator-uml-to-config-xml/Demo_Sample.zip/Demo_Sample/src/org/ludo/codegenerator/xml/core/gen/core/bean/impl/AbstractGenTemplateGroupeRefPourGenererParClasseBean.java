package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParClasse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenTemplateGroupeRefPourGenererParClasseBean implements IGenTemplateGroupeRefPourGenererParClasse {
	
	/** Récupération de l'élément parent */
	
	private IGenTemplateGroupesRefPourGenererParClasse referenceGenTemplateGroupesRefPourGenererParClasse = null;
	
	public IGenTemplateGroupesRefPourGenererParClasse getReferenceGenTemplateGroupesRefPourGenererParClasse() {
		return referenceGenTemplateGroupesRefPourGenererParClasse;
	}
	
	public void setReferenceGenTemplateGroupesRefPourGenererParClasse(IGenTemplateGroupesRefPourGenererParClasse referenceGenTemplateGroupesRefPourGenererParClasse) {
		this.referenceGenTemplateGroupesRefPourGenererParClasse = referenceGenTemplateGroupesRefPourGenererParClasse;
	}
	
	/** Récupération des éléments fils */
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	

	public String getTemplateGroupeNomAsString() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString) {
		this.templateGroupeNom = templateGroupeNomAsString;
	}
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
	private String templateGroupeNom = null;

	public String getTemplateGroupeNom() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNom(String templateGroupeNom) {
		this.templateGroupeNom = templateGroupeNom;
	}
}
