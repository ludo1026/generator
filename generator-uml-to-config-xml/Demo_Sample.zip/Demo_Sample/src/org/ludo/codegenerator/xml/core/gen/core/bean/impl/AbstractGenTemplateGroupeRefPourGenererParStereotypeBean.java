package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenTemplateGroupeRefPourGenererParStereotypeBean implements IGenTemplateGroupeRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	private IGenTemplateGroupesRefPourGenererParStereotype referenceGenTemplateGroupesRefPourGenererParStereotype = null;
	
	public IGenTemplateGroupesRefPourGenererParStereotype getReferenceGenTemplateGroupesRefPourGenererParStereotype() {
		return referenceGenTemplateGroupesRefPourGenererParStereotype;
	}
	
	public void setReferenceGenTemplateGroupesRefPourGenererParStereotype(IGenTemplateGroupesRefPourGenererParStereotype referenceGenTemplateGroupesRefPourGenererParStereotype) {
		this.referenceGenTemplateGroupesRefPourGenererParStereotype = referenceGenTemplateGroupesRefPourGenererParStereotype;
	}
	
	/** Récupération des éléments fils */
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	

	public String getTemplateGroupeNomAsString() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNomAsString(String templateGroupeNomAsString) {
		this.templateGroupeNom = templateGroupeNomAsString;
	}
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
	private String templateGroupeNom = null;

	public String getTemplateGroupeNom() {
		return this.templateGroupeNom;
	}
	public void setTemplateGroupeNom(String templateGroupeNom) {
		this.templateGroupeNom = templateGroupeNom;
	}
}
