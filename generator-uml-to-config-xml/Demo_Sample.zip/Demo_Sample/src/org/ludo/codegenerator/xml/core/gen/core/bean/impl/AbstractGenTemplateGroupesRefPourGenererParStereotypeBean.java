package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParStereotype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenTemplateGroupesRefPourGenererParStereotypeBean implements IGenTemplateGroupesRefPourGenererParStereotype {
	
	/** Récupération de l'élément parent */
	
	private IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype = null;
	
	public IGenStereotypeRefPourGenererParStereotype getReferenceGenStereotypeRefPourGenererParStereotype() {
		return referenceGenStereotypeRefPourGenererParStereotype;
	}
	
	public void setReferenceGenStereotypeRefPourGenererParStereotype(IGenStereotypeRefPourGenererParStereotype referenceGenStereotypeRefPourGenererParStereotype) {
		this.referenceGenStereotypeRefPourGenererParStereotype = referenceGenStereotypeRefPourGenererParStereotype;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenTemplateGroupeRefPourGenererParStereotype = new ArrayList();
	
    public IGenTemplateGroupeRefPourGenererParStereotype getGenTemplateGroupeRefPourGenererParStereotypeByTemplateGroupeNom(String templateGroupeNom) {
        for(Iterator iter = listeGenTemplateGroupeRefPourGenererParStereotype.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeRefPourGenererParStereotypeBean genTemplateGroupeRefPourGenererParStereotype = (GenTemplateGroupeRefPourGenererParStereotypeBean) iter.next();
            if(genTemplateGroupeRefPourGenererParStereotype.getTemplateGroupeNom().equalsIgnoreCase(templateGroupeNom)) {
                return genTemplateGroupeRefPourGenererParStereotype;
            }
        }
        throw new IllegalStateException("La genTemplateGroupeRefPourGenererParStereotype n'est pas définie : templateGroupeNom de genTemplateGroupeRefPourGenererParStereotype = "+templateGroupeNom);
    }
    public void addGenTemplateGroupeRefPourGenererParStereotype(IGenTemplateGroupeRefPourGenererParStereotype genTemplateGroupeRefPourGenererParStereotype) {
    	genTemplateGroupeRefPourGenererParStereotype.setReferenceGenTemplateGroupesRefPourGenererParStereotype(this);
        listeGenTemplateGroupeRefPourGenererParStereotype.add(genTemplateGroupeRefPourGenererParStereotype);
    }
    public List getListeGenTemplateGroupeRefPourGenererParStereotype() {
        return listeGenTemplateGroupeRefPourGenererParStereotype;
    }
    public void setListeGenTemplateGroupeRefPourGenererParStereotype(List listeGenTemplateGroupeRefPourGenererParStereotype) {
        this.listeGenTemplateGroupeRefPourGenererParStereotype = listeGenTemplateGroupeRefPourGenererParStereotype;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
