package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AbstractGenTemplateGroupesRefPourGenererParTemplateBean implements IGenTemplateGroupesRefPourGenererParTemplate {
	
	/** Récupération de l'élément parent */
	
	private IGenGenererParTemplate referenceGenGenererParTemplate = null;
	
	public IGenGenererParTemplate getReferenceGenGenererParTemplate() {
		return referenceGenGenererParTemplate;
	}
	
	public void setReferenceGenGenererParTemplate(IGenGenererParTemplate referenceGenGenererParTemplate) {
		this.referenceGenGenererParTemplate = referenceGenGenererParTemplate;
	}
	
	/** Récupération des éléments fils */
	
    private List listeGenTemplateGroupeRefPourGenererParTemplate = new ArrayList();
	
    public IGenTemplateGroupeRefPourGenererParTemplate getGenTemplateGroupeRefPourGenererParTemplateByTemplateGroupeNom(String templateGroupeNom) {
        for(Iterator iter = listeGenTemplateGroupeRefPourGenererParTemplate.iterator(); iter.hasNext(); ) {
            GenTemplateGroupeRefPourGenererParTemplateBean genTemplateGroupeRefPourGenererParTemplate = (GenTemplateGroupeRefPourGenererParTemplateBean) iter.next();
            if(genTemplateGroupeRefPourGenererParTemplate.getTemplateGroupeNom().equalsIgnoreCase(templateGroupeNom)) {
                return genTemplateGroupeRefPourGenererParTemplate;
            }
        }
        throw new IllegalStateException("La genTemplateGroupeRefPourGenererParTemplate n'est pas définie : templateGroupeNom de genTemplateGroupeRefPourGenererParTemplate = "+templateGroupeNom);
    }
    public void addGenTemplateGroupeRefPourGenererParTemplate(IGenTemplateGroupeRefPourGenererParTemplate genTemplateGroupeRefPourGenererParTemplate) {
    	genTemplateGroupeRefPourGenererParTemplate.setReferenceGenTemplateGroupesRefPourGenererParTemplate(this);
        listeGenTemplateGroupeRefPourGenererParTemplate.add(genTemplateGroupeRefPourGenererParTemplate);
    }
    public List getListeGenTemplateGroupeRefPourGenererParTemplate() {
        return listeGenTemplateGroupeRefPourGenererParTemplate;
    }
    public void setListeGenTemplateGroupeRefPourGenererParTemplate(List listeGenTemplateGroupeRefPourGenererParTemplate) {
        this.listeGenTemplateGroupeRefPourGenererParTemplate = listeGenTemplateGroupeRefPourGenererParTemplate;
    }
	
	/** Récupération des attributs de l'objet de base sans transtypage */
	
	
	/** Récupération des attributs de l'objet de base avec transtypage */
	
}
