package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociation;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenAssociationBean;

public class GenAssociationBean extends AbstractGenAssociationBean {
	
}
