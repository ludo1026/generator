package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAssociations;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenAssociationsBean;

public class GenAssociationsBean extends AbstractGenAssociationsBean {
	
}
