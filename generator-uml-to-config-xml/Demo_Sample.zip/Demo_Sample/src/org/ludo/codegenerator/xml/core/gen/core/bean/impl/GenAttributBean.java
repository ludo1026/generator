package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenAttribut;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenAttributBean;

public class GenAttributBean extends AbstractGenAttributBean {
	
}
