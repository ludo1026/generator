package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGen;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenBean;

public class GenBean extends AbstractGenBean {
	
}
