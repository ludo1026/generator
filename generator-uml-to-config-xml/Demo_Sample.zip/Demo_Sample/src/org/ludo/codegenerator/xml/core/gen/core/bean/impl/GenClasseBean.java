package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClasseBean;

public class GenClasseBean extends AbstractGenClasseBean {
	
}
