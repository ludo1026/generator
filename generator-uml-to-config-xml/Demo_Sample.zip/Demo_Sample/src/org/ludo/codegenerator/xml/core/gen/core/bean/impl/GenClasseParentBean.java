package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseParent;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClasseParentBean;

public class GenClasseParentBean extends AbstractGenClasseParentBean {
	
}
