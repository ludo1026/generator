package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseParents;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClasseParentsBean;

public class GenClasseParentsBean extends AbstractGenClasseParentsBean {
	
}
