package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasseRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClasseRefPourGenererParClasseBean;

public class GenClasseRefPourGenererParClasseBean extends AbstractGenClasseRefPourGenererParClasseBean {
	
}
