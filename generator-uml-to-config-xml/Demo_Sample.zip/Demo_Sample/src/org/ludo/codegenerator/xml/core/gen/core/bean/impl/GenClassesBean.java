package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClassesBean;

public class GenClassesBean extends AbstractGenClassesBean {
	
}
