package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenClassesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenClassesRefPourGenererParClasseBean;

public class GenClassesRefPourGenererParClasseBean extends AbstractGenClassesRefPourGenererParClasseBean {
	
}
