package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererGroupeBean;

public class GenGenererGroupeBean extends AbstractGenGenererGroupeBean {
	
}
