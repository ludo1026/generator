package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParClasseBean;

public class GenGenererParClasseBean extends AbstractGenGenererParClasseBean {
	
}
