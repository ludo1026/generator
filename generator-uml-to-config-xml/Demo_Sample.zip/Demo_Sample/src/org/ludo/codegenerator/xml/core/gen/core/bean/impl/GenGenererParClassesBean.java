package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParClasses;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParClassesBean;

public class GenGenererParClassesBean extends AbstractGenGenererParClassesBean {
	
}
