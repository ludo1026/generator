package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParStereotypeBean;

public class GenGenererParStereotypeBean extends AbstractGenGenererParStereotypeBean {
	
}
