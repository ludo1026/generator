package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParStereotypesBean;

public class GenGenererParStereotypesBean extends AbstractGenGenererParStereotypesBean {
	
}
