package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParTemplateBean;

public class GenGenererParTemplateBean extends AbstractGenGenererParTemplateBean {
	
}
