package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenGenererParTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenGenererParTemplatesBean;

public class GenGenererParTemplatesBean extends AbstractGenGenererParTemplatesBean {
	
}
