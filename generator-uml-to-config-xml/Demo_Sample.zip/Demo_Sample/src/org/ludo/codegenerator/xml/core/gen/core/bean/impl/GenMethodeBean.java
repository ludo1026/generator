package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethode;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenMethodeBean;

public class GenMethodeBean extends AbstractGenMethodeBean {
	
}
