package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenMethodes;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenMethodesBean;

public class GenMethodesBean extends AbstractGenMethodesBean {
	
}
