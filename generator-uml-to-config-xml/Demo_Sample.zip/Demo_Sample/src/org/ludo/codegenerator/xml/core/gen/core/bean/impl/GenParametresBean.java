package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenParametres;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenParametresBean;

public class GenParametresBean extends AbstractGenParametresBean {
	
}
