package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypeBean;

public class GenStereotypeBean extends AbstractGenStereotypeBean {
	
}
