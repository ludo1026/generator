package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypeRefBean;

public class GenStereotypeRefBean extends AbstractGenStereotypeRefBean {
	
}
