package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypeRefPourGenererParStereotypeBean;

public class GenStereotypeRefPourGenererParStereotypeBean extends AbstractGenStereotypeRefPourGenererParStereotypeBean {
	
}
