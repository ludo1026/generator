package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypeRefPourGenererParTemplateBean;

public class GenStereotypeRefPourGenererParTemplateBean extends AbstractGenStereotypeRefPourGenererParTemplateBean {
	
}
