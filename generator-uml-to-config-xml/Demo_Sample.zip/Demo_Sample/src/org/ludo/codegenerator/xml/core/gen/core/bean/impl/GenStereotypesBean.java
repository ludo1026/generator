package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypes;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypesBean;

public class GenStereotypesBean extends AbstractGenStereotypesBean {
	
}
