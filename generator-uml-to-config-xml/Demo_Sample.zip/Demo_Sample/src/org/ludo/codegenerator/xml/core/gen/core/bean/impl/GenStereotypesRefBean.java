package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypesRefBean;

public class GenStereotypesRefBean extends AbstractGenStereotypesRefBean {
	
}
