package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypesRefPourGenererParStereotypeBean;

public class GenStereotypesRefPourGenererParStereotypeBean extends AbstractGenStereotypesRefPourGenererParStereotypeBean {
	
}
