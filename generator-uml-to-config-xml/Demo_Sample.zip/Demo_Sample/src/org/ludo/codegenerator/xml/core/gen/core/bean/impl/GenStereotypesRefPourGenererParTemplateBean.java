package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenStereotypesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenStereotypesRefPourGenererParTemplateBean;

public class GenStereotypesRefPourGenererParTemplateBean extends AbstractGenStereotypesRefPourGenererParTemplateBean {
	
}
