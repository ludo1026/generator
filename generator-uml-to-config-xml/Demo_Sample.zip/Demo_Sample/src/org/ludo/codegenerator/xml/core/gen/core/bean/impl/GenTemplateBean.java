package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateBean;

public class GenTemplateBean extends AbstractGenTemplateBean {
	
}
