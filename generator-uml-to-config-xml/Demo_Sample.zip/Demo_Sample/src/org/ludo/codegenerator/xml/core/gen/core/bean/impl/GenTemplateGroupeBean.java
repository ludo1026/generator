package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupe;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupeBean;

public class GenTemplateGroupeBean extends AbstractGenTemplateGroupeBean {
	
}
