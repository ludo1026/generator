package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupeRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupeRefPourGenererParTemplateBean;

public class GenTemplateGroupeRefPourGenererParTemplateBean extends AbstractGenTemplateGroupeRefPourGenererParTemplateBean {
	
}
