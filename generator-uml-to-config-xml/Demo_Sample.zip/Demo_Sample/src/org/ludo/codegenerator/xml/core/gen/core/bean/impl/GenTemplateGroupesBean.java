package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupes;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupesBean;

public class GenTemplateGroupesBean extends AbstractGenTemplateGroupesBean {
	
}
