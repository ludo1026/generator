package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParClasse;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupesRefPourGenererParClasseBean;

public class GenTemplateGroupesRefPourGenererParClasseBean extends AbstractGenTemplateGroupesRefPourGenererParClasseBean {
	
}
