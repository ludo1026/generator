package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParStereotype;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupesRefPourGenererParStereotypeBean;

public class GenTemplateGroupesRefPourGenererParStereotypeBean extends AbstractGenTemplateGroupesRefPourGenererParStereotypeBean {
	
}
