package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateGroupesRefPourGenererParTemplate;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateGroupesRefPourGenererParTemplateBean;

public class GenTemplateGroupesRefPourGenererParTemplateBean extends AbstractGenTemplateGroupesRefPourGenererParTemplateBean {
	
}
