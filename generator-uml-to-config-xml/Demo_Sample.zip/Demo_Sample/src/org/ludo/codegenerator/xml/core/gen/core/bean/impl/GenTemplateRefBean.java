package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplateRef;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplateRefBean;

public class GenTemplateRefBean extends AbstractGenTemplateRefBean {
	
}
