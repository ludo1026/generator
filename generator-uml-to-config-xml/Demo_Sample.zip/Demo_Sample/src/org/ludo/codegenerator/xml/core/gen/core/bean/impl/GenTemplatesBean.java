package org.ludo.codegenerator.xml.core.gen.core.bean.impl;

import org.ludo.codegenerator.xml.core.gen.core.bean.IGenTemplates;
import org.ludo.codegenerator.xml.core.gen.core.bean.impl.AbstractGenTemplatesBean;

public class GenTemplatesBean extends AbstractGenTemplatesBean {
	
}
